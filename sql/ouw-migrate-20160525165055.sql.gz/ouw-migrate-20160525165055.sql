# WordPress MySQL database migration
#
# Generated: Wednesday 25. May 2016 16:50 UTC
# Hostname: localhost
# Database: `ouw`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_commentmeta`
#

DROP TABLE IF EXISTS `wp_commentmeta`;


#
# Table structure of table `wp_commentmeta`
#

CREATE TABLE `wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_commentmeta`
#
INSERT INTO `wp_commentmeta` ( `meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(1, 3, 'rating', '2'),
(2, 3, 'verified', '0'),
(3, 4, 'rating', '4'),
(4, 4, 'verified', '0'),
(5, 5, 'rating', '4'),
(6, 5, 'verified', '0'),
(7, 7, 'rating', '2'),
(8, 7, 'verified', '0'),
(9, 8, 'rating', '4'),
(10, 8, 'verified', '0'),
(11, 9, 'rating', '4'),
(12, 9, 'verified', '0') ;

#
# End of data contents of table `wp_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_comments`
#

DROP TABLE IF EXISTS `wp_comments`;


#
# Table structure of table `wp_comments`
#

CREATE TABLE `wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_comments`
#
INSERT INTO `wp_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Monsieur WordPress', '', 'https://wordpress.org/', '', '2016-05-11 01:46:42', '2016-05-10 23:46:42', 'Bonjour, ceci est un commentaire.\nPour supprimer un commentaire, connectez-vous et affichez les commentaires de cet article. Vous pourrez alors les modifier ou les supprimer.', 0, 'post-trashed', '', '', 0, 0),
(2, 20, 'Alex', 'alexandre.kong@gmail.com', '', '::1', '2016-05-17 02:58:07', '2016-05-17 00:58:07', 'Je suis un commentaire', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36', '', 0, 1),
(3, 38, 'Alex', 'alexandre.kong@gmail.com', '', '::1', '2016-05-19 16:38:35', '2016-05-19 14:38:35', 'Je suis content !', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36', '', 0, 1),
(4, 38, 'Alex', 'alexandre.kong@gmail.com', '', '::1', '2016-05-19 16:53:19', '2016-05-19 14:53:19', 'Moi aussi je suis content !!!', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36', '', 0, 1),
(5, 58, 'Alex', 'alexandre.kong@gmail.com', '', '::1', '2016-05-19 17:02:20', '2016-05-19 15:02:20', 'Génial !', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36', '', 0, 1),
(6, 63, 'WooCommerce', '', '', '', '2016-05-19 18:08:35', '2016-05-19 16:08:35', 'État de la commande modifiée de Attente paiement à En cours', 0, '1', 'WooCommerce', 'order_note', 0, 0),
(7, 55, 'Alex', 'alexandre.kong@gmail.com', '', '::1', '2016-05-19 18:13:17', '2016-05-19 16:13:17', 'Hello', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36', '', 0, 1),
(8, 58, 'Alexandre Kong', 'kngalexandre@gmail.com', '', '::1', '2016-05-22 23:21:21', '2016-05-22 21:21:21', 'C\'est une très belle montre', 0, '0', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36', '', 0, 0),
(9, 58, 'Alex', 'alexandre.kong@gmail.com', '', '::1', '2016-05-23 11:34:11', '2016-05-23 09:34:11', 'Superbe montre !', 0, '1', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36', '', 0, 1) ;

#
# End of data contents of table `wp_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_links`
#

DROP TABLE IF EXISTS `wp_links`;


#
# Table structure of table `wp_links`
#

CREATE TABLE `wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_links`
#

#
# End of data contents of table `wp_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_options`
#

DROP TABLE IF EXISTS `wp_options`;


#
# Table structure of table `wp_options`
#

CREATE TABLE `wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=8464 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_options`
#
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8888/onceuponawatch', 'yes'),
(2, 'home', 'http://localhost:8888/onceuponawatch', 'yes'),
(3, 'blogname', 'Once Upon a Watch', 'yes'),
(4, 'blogdescription', 'Un site utilisant WordPress', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'alexandre.kong@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '1', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'G \\h i \\m\\i\\n', 'yes'),
(25, 'links_updated_date_format', 'j F Y G \\h i \\m\\i\\n', 'yes'),
(26, 'comment_moderation', '', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'rewrite_rules', 'a:214:{s:22:"^wc-api/v([1-3]{1})/?$";s:51:"index.php?wc-api-version=$matches[1]&wc-api-route=/";s:24:"^wc-api/v([1-3]{1})(.*)?";s:61:"index.php?wc-api-version=$matches[1]&wc-api-route=$matches[2]";s:24:"^wc-auth/v([1]{1})/(.*)?";s:63:"index.php?wc-auth-version=$matches[1]&wc-auth-route=$matches[2]";s:11:"annonces/?$";s:28:"index.php?post_type=annonces";s:41:"annonces/feed/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=annonces&feed=$matches[1]";s:36:"annonces/(feed|rdf|rss|rss2|atom)/?$";s:45:"index.php?post_type=annonces&feed=$matches[1]";s:28:"annonces/page/([0-9]{1,})/?$";s:46:"index.php?post_type=annonces&paged=$matches[1]";s:11:"boutique/?$";s:27:"index.php?post_type=product";s:41:"boutique/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:36:"boutique/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=product&feed=$matches[1]";s:28:"boutique/page/([0-9]{1,})/?$";s:45:"index.php?post_type=product&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:32:"category/(.+?)/wc-api(/(.*))?/?$";s:54:"index.php?category_name=$matches[1]&wc-api=$matches[3]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:29:"tag/([^/]+)/wc-api(/(.*))?/?$";s:44:"index.php?tag=$matches[1]&wc-api=$matches[3]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:34:"annonces/.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"annonces/.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"annonces/.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"annonces/.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"annonces/.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"annonces/.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:23:"annonces/(.+?)/embed/?$";s:41:"index.php?annonces=$matches[1]&embed=true";s:27:"annonces/(.+?)/trackback/?$";s:35:"index.php?annonces=$matches[1]&tb=1";s:47:"annonces/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?annonces=$matches[1]&feed=$matches[2]";s:42:"annonces/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?annonces=$matches[1]&feed=$matches[2]";s:35:"annonces/(.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?annonces=$matches[1]&paged=$matches[2]";s:42:"annonces/(.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?annonces=$matches[1]&cpage=$matches[2]";s:32:"annonces/(.+?)/wc-api(/(.*))?/?$";s:49:"index.php?annonces=$matches[1]&wc-api=$matches[3]";s:38:"annonces/.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:49:"annonces/.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:31:"annonces/(.+?)(?:/([0-9]+))?/?$";s:47:"index.php?annonces=$matches[1]&page=$matches[2]";s:56:"categorie-produit/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:51:"categorie-produit/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_cat=$matches[1]&feed=$matches[2]";s:32:"categorie-produit/(.+?)/embed/?$";s:44:"index.php?product_cat=$matches[1]&embed=true";s:44:"categorie-produit/(.+?)/page/?([0-9]{1,})/?$";s:51:"index.php?product_cat=$matches[1]&paged=$matches[2]";s:26:"categorie-produit/(.+?)/?$";s:33:"index.php?product_cat=$matches[1]";s:58:"etiquette-produit/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:53:"etiquette-produit/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?product_tag=$matches[1]&feed=$matches[2]";s:34:"etiquette-produit/([^/]+)/embed/?$";s:44:"index.php?product_tag=$matches[1]&embed=true";s:46:"etiquette-produit/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?product_tag=$matches[1]&paged=$matches[2]";s:28:"etiquette-produit/([^/]+)/?$";s:33:"index.php?product_tag=$matches[1]";s:35:"produit/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"produit/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"produit/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"produit/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"produit/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"produit/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"produit/([^/]+)/embed/?$";s:40:"index.php?product=$matches[1]&embed=true";s:28:"produit/([^/]+)/trackback/?$";s:34:"index.php?product=$matches[1]&tb=1";s:48:"produit/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:43:"produit/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?product=$matches[1]&feed=$matches[2]";s:36:"produit/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&paged=$matches[2]";s:43:"produit/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?product=$matches[1]&cpage=$matches[2]";s:33:"produit/([^/]+)/wc-api(/(.*))?/?$";s:48:"index.php?product=$matches[1]&wc-api=$matches[3]";s:39:"produit/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:50:"produit/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:32:"produit/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?product=$matches[1]&page=$matches[2]";s:24:"produit/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"produit/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"produit/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"produit/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"produit/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:30:"produit/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:45:"product_variation/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"product_variation/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"product_variation/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"product_variation/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"product_variation/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"product_variation/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"product_variation/([^/]+)/embed/?$";s:50:"index.php?product_variation=$matches[1]&embed=true";s:38:"product_variation/([^/]+)/trackback/?$";s:44:"index.php?product_variation=$matches[1]&tb=1";s:46:"product_variation/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?product_variation=$matches[1]&paged=$matches[2]";s:53:"product_variation/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?product_variation=$matches[1]&cpage=$matches[2]";s:43:"product_variation/([^/]+)/wc-api(/(.*))?/?$";s:58:"index.php?product_variation=$matches[1]&wc-api=$matches[3]";s:49:"product_variation/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:60:"product_variation/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"product_variation/([^/]+)(?:/([0-9]+))?/?$";s:56:"index.php?product_variation=$matches[1]&page=$matches[2]";s:34:"product_variation/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"product_variation/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"product_variation/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"product_variation/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"product_variation/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"product_variation/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:45:"shop_order_refund/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:55:"shop_order_refund/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:75:"shop_order_refund/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"shop_order_refund/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:70:"shop_order_refund/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"shop_order_refund/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:34:"shop_order_refund/([^/]+)/embed/?$";s:50:"index.php?shop_order_refund=$matches[1]&embed=true";s:38:"shop_order_refund/([^/]+)/trackback/?$";s:44:"index.php?shop_order_refund=$matches[1]&tb=1";s:46:"shop_order_refund/([^/]+)/page/?([0-9]{1,})/?$";s:57:"index.php?shop_order_refund=$matches[1]&paged=$matches[2]";s:53:"shop_order_refund/([^/]+)/comment-page-([0-9]{1,})/?$";s:57:"index.php?shop_order_refund=$matches[1]&cpage=$matches[2]";s:43:"shop_order_refund/([^/]+)/wc-api(/(.*))?/?$";s:58:"index.php?shop_order_refund=$matches[1]&wc-api=$matches[3]";s:49:"shop_order_refund/[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:60:"shop_order_refund/[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"shop_order_refund/([^/]+)(?:/([0-9]+))?/?$";s:56:"index.php?shop_order_refund=$matches[1]&page=$matches[2]";s:34:"shop_order_refund/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:44:"shop_order_refund/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:64:"shop_order_refund/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"shop_order_refund/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:59:"shop_order_refund/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:40:"shop_order_refund/[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:17:"wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:20:"order-pay(/(.*))?/?$";s:32:"index.php?&order-pay=$matches[2]";s:25:"order-received(/(.*))?/?$";s:37:"index.php?&order-received=$matches[2]";s:21:"view-order(/(.*))?/?$";s:33:"index.php?&view-order=$matches[2]";s:23:"edit-account(/(.*))?/?$";s:35:"index.php?&edit-account=$matches[2]";s:23:"edit-address(/(.*))?/?$";s:35:"index.php?&edit-address=$matches[2]";s:24:"lost-password(/(.*))?/?$";s:36:"index.php?&lost-password=$matches[2]";s:26:"customer-logout(/(.*))?/?$";s:38:"index.php?&customer-logout=$matches[2]";s:29:"add-payment-method(/(.*))?/?$";s:41:"index.php?&add-payment-method=$matches[2]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:26:"comments/wc-api(/(.*))?/?$";s:29:"index.php?&wc-api=$matches[2]";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:29:"search/(.+)/wc-api(/(.*))?/?$";s:42:"index.php?s=$matches[1]&wc-api=$matches[3]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:32:"author/([^/]+)/wc-api(/(.*))?/?$";s:52:"index.php?author_name=$matches[1]&wc-api=$matches[3]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:54:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&wc-api=$matches[5]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:41:"([0-9]{4})/([0-9]{1,2})/wc-api(/(.*))?/?$";s:66:"index.php?year=$matches[1]&monthnum=$matches[2]&wc-api=$matches[4]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:28:"([0-9]{4})/wc-api(/(.*))?/?$";s:45:"index.php?year=$matches[1]&wc-api=$matches[3]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:25:"(.?.+?)/wc-api(/(.*))?/?$";s:49:"index.php?pagename=$matches[1]&wc-api=$matches[3]";s:28:"(.?.+?)/order-pay(/(.*))?/?$";s:52:"index.php?pagename=$matches[1]&order-pay=$matches[3]";s:33:"(.?.+?)/order-received(/(.*))?/?$";s:57:"index.php?pagename=$matches[1]&order-received=$matches[3]";s:29:"(.?.+?)/view-order(/(.*))?/?$";s:53:"index.php?pagename=$matches[1]&view-order=$matches[3]";s:31:"(.?.+?)/edit-account(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-account=$matches[3]";s:31:"(.?.+?)/edit-address(/(.*))?/?$";s:55:"index.php?pagename=$matches[1]&edit-address=$matches[3]";s:32:"(.?.+?)/lost-password(/(.*))?/?$";s:56:"index.php?pagename=$matches[1]&lost-password=$matches[3]";s:34:"(.?.+?)/customer-logout(/(.*))?/?$";s:58:"index.php?pagename=$matches[1]&customer-logout=$matches[3]";s:37:"(.?.+?)/add-payment-method(/(.*))?/?$";s:61:"index.php?pagename=$matches[1]&add-payment-method=$matches[3]";s:31:".?.+?/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:".?.+?/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:25:"([^/]+)/wc-api(/(.*))?/?$";s:45:"index.php?name=$matches[1]&wc-api=$matches[3]";s:31:"[^/]+/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:42:"[^/]+/attachment/([^/]+)/wc-api(/(.*))?/?$";s:51:"index.php?attachment=$matches[1]&wc-api=$matches[3]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(30, 'hack_file', '0', 'yes'),
(31, 'blog_charset', 'UTF-8', 'yes'),
(32, 'moderation_keys', '', 'no'),
(33, 'active_plugins', 'a:8:{i:0;s:37:"ajax-search-lite/ajax-search-lite.php";i:1;s:36:"contact-form-7/wp-contact-form-7.php";i:2;s:53:"mousewheel-smooth-scroll/mousewheel-smooth-scroll.php";i:3;s:51:"post-type-archive-links/post-type-archive-links.php";i:4;s:27:"woocommerce/woocommerce.php";i:5;s:24:"wordpress-seo/wp-seo.php";i:6;s:25:"wp-members/wp-members.php";i:7;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(34, 'category_base', '', 'yes'),
(35, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(36, 'comment_max_links', '2', 'yes'),
(37, 'gmt_offset', '0', 'yes'),
(38, 'default_email_category', '1', 'yes'),
(39, 'recently_edited', 'a:4:{i:0;s:85:"/Applications/MAMP/htdocs/onceuponawatch/wp-content/plugins/wp-members/wp-members.php";i:1;s:87:"/Applications/MAMP/htdocs/onceuponawatch/wp-content/themes/onceuponawatch_old/style.css";i:2;s:97:"/Applications/MAMP/htdocs/onceuponawatch/wp-content/plugins/ajax-search-lite/ajax-search-lite.php";i:3;s:0:"";}', 'no'),
(40, 'template', 'onceuponawatch_old', 'yes'),
(41, 'stylesheet', 'onceuponawatch_old', 'yes'),
(42, 'comment_whitelist', '1', 'yes'),
(43, 'blacklist_keys', '', 'no'),
(44, 'comment_registration', '1', 'yes'),
(45, 'html_type', 'text/html', 'yes'),
(46, 'use_trackback', '0', 'yes'),
(47, 'default_role', 'subscriber', 'yes'),
(48, 'db_version', '36686', 'yes'),
(49, 'uploads_use_yearmonth_folders', '1', 'yes'),
(50, 'upload_path', '', 'yes'),
(51, 'blog_public', '1', 'yes'),
(52, 'default_link_category', '2', 'yes'),
(53, 'show_on_front', 'posts', 'yes'),
(54, 'tag_base', '', 'yes'),
(55, 'show_avatars', '1', 'yes'),
(56, 'avatar_rating', 'G', 'yes'),
(57, 'upload_url_path', '', 'yes'),
(58, 'thumbnail_size_w', '150', 'yes'),
(59, 'thumbnail_size_h', '150', 'yes'),
(60, 'thumbnail_crop', '1', 'yes'),
(61, 'medium_size_w', '300', 'yes'),
(62, 'medium_size_h', '300', 'yes'),
(63, 'avatar_default', 'mystery', 'yes'),
(64, 'large_size_w', '1024', 'yes'),
(65, 'large_size_h', '1024', 'yes'),
(66, 'image_default_link_type', 'none', 'yes'),
(67, 'image_default_size', '', 'yes'),
(68, 'image_default_align', '', 'yes'),
(69, 'close_comments_for_old_posts', '', 'yes'),
(70, 'close_comments_days_old', '14', 'yes'),
(71, 'thread_comments', '1', 'yes'),
(72, 'thread_comments_depth', '5', 'yes'),
(73, 'page_comments', '', 'yes'),
(74, 'comments_per_page', '50', 'yes'),
(75, 'default_comments_page', 'newest', 'yes'),
(76, 'comment_order', 'asc', 'yes'),
(77, 'sticky_posts', 'a:0:{}', 'yes'),
(78, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(81, 'uninstall_plugins', 'a:0:{}', 'no'),
(82, 'timezone_string', 'Europe/Paris', 'yes'),
(83, 'page_for_posts', '0', 'yes'),
(84, 'page_on_front', '0', 'yes'),
(85, 'default_post_format', '0', 'yes'),
(86, 'link_manager_enabled', '0', 'yes'),
(87, 'finished_splitting_shared_terms', '1', 'yes'),
(88, 'site_icon', '0', 'yes'),
(89, 'medium_large_size_w', '768', 'yes'),
(90, 'medium_large_size_h', '0', 'yes'),
(91, 'initial_db_version', '36686', 'yes'),
(92, 'wp_user_roles', 'a:7:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:132:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;s:17:"edit_shop_webhook";b:1;s:17:"read_shop_webhook";b:1;s:19:"delete_shop_webhook";b:1;s:18:"edit_shop_webhooks";b:1;s:25:"edit_others_shop_webhooks";b:1;s:21:"publish_shop_webhooks";b:1;s:26:"read_private_shop_webhooks";b:1;s:20:"delete_shop_webhooks";b:1;s:28:"delete_private_shop_webhooks";b:1;s:30:"delete_published_shop_webhooks";b:1;s:27:"delete_others_shop_webhooks";b:1;s:26:"edit_private_shop_webhooks";b:1;s:28:"edit_published_shop_webhooks";b:1;s:25:"manage_shop_webhook_terms";b:1;s:23:"edit_shop_webhook_terms";b:1;s:25:"delete_shop_webhook_terms";b:1;s:25:"assign_shop_webhook_terms";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}s:8:"customer";a:2:{s:4:"name";s:8:"Customer";s:12:"capabilities";a:1:{s:4:"read";b:1;}}s:12:"shop_manager";a:2:{s:4:"name";s:12:"Shop Manager";s:12:"capabilities";a:110:{s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:4:"read";b:1;s:18:"read_private_pages";b:1;s:18:"read_private_posts";b:1;s:10:"edit_users";b:1;s:10:"edit_posts";b:1;s:10:"edit_pages";b:1;s:20:"edit_published_posts";b:1;s:20:"edit_published_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"edit_private_posts";b:1;s:17:"edit_others_posts";b:1;s:17:"edit_others_pages";b:1;s:13:"publish_posts";b:1;s:13:"publish_pages";b:1;s:12:"delete_posts";b:1;s:12:"delete_pages";b:1;s:20:"delete_private_pages";b:1;s:20:"delete_private_posts";b:1;s:22:"delete_published_pages";b:1;s:22:"delete_published_posts";b:1;s:19:"delete_others_posts";b:1;s:19:"delete_others_pages";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:17:"moderate_comments";b:1;s:15:"unfiltered_html";b:1;s:12:"upload_files";b:1;s:6:"export";b:1;s:6:"import";b:1;s:10:"list_users";b:1;s:18:"manage_woocommerce";b:1;s:24:"view_woocommerce_reports";b:1;s:12:"edit_product";b:1;s:12:"read_product";b:1;s:14:"delete_product";b:1;s:13:"edit_products";b:1;s:20:"edit_others_products";b:1;s:16:"publish_products";b:1;s:21:"read_private_products";b:1;s:15:"delete_products";b:1;s:23:"delete_private_products";b:1;s:25:"delete_published_products";b:1;s:22:"delete_others_products";b:1;s:21:"edit_private_products";b:1;s:23:"edit_published_products";b:1;s:20:"manage_product_terms";b:1;s:18:"edit_product_terms";b:1;s:20:"delete_product_terms";b:1;s:20:"assign_product_terms";b:1;s:15:"edit_shop_order";b:1;s:15:"read_shop_order";b:1;s:17:"delete_shop_order";b:1;s:16:"edit_shop_orders";b:1;s:23:"edit_others_shop_orders";b:1;s:19:"publish_shop_orders";b:1;s:24:"read_private_shop_orders";b:1;s:18:"delete_shop_orders";b:1;s:26:"delete_private_shop_orders";b:1;s:28:"delete_published_shop_orders";b:1;s:25:"delete_others_shop_orders";b:1;s:24:"edit_private_shop_orders";b:1;s:26:"edit_published_shop_orders";b:1;s:23:"manage_shop_order_terms";b:1;s:21:"edit_shop_order_terms";b:1;s:23:"delete_shop_order_terms";b:1;s:23:"assign_shop_order_terms";b:1;s:16:"edit_shop_coupon";b:1;s:16:"read_shop_coupon";b:1;s:18:"delete_shop_coupon";b:1;s:17:"edit_shop_coupons";b:1;s:24:"edit_others_shop_coupons";b:1;s:20:"publish_shop_coupons";b:1;s:25:"read_private_shop_coupons";b:1;s:19:"delete_shop_coupons";b:1;s:27:"delete_private_shop_coupons";b:1;s:29:"delete_published_shop_coupons";b:1;s:26:"delete_others_shop_coupons";b:1;s:25:"edit_private_shop_coupons";b:1;s:27:"edit_published_shop_coupons";b:1;s:24:"manage_shop_coupon_terms";b:1;s:22:"edit_shop_coupon_terms";b:1;s:24:"delete_shop_coupon_terms";b:1;s:24:"assign_shop_coupon_terms";b:1;s:17:"edit_shop_webhook";b:1;s:17:"read_shop_webhook";b:1;s:19:"delete_shop_webhook";b:1;s:18:"edit_shop_webhooks";b:1;s:25:"edit_others_shop_webhooks";b:1;s:21:"publish_shop_webhooks";b:1;s:26:"read_private_shop_webhooks";b:1;s:20:"delete_shop_webhooks";b:1;s:28:"delete_private_shop_webhooks";b:1;s:30:"delete_published_shop_webhooks";b:1;s:27:"delete_others_shop_webhooks";b:1;s:26:"edit_private_shop_webhooks";b:1;s:28:"edit_published_shop_webhooks";b:1;s:25:"manage_shop_webhook_terms";b:1;s:23:"edit_shop_webhook_terms";b:1;s:25:"delete_shop_webhook_terms";b:1;s:25:"assign_shop_webhook_terms";b:1;}}}', 'yes'),
(93, 'WPLANG', 'fr_FR', 'yes'),
(94, 'widget_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-posts', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_recent-comments', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'widget_meta', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(99, 'sidebars_widgets', 'a:5:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-widgets";a:6:{i:0;s:25:"woocommerce_widget_cart-2";i:1;s:25:"woocommerce_layered_nav-2";i:2;s:33:"woocommerce_layered_nav_filters-2";i:3;s:22:"woocommerce_products-2";i:4;s:12:"categories-2";i:5;s:10:"archives-2";}s:14:"footer-widgets";a:0:{}s:19:"filtres-woocommerce";a:3:{i:0;s:32:"woocommerce_product_categories-2";i:1;s:25:"woocommerce_layered_nav-3";i:2;s:26:"woocommerce_price_filter-2";}s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(102, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'cron', 'a:10:{i:1464196243;a:1:{s:29:"wp_session_garbage_collection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1464198035;a:1:{s:32:"woocommerce_cancel_unpaid_orders";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:2:{s:8:"schedule";b:0;s:4:"args";a:0:{}}}}i:1464220002;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1464220017;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1464220480;a:1:{s:28:"woocommerce_cleanup_sessions";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1464228000;a:1:{s:27:"woocommerce_scheduled_sales";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1464263680;a:1:{s:30:"woocommerce_tracker_send_event";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1464263702;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1465257600;a:1:{s:25:"woocommerce_geoip_updater";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:7:"monthly";s:4:"args";a:0:{}s:8:"interval";i:2635200;}}}s:7:"version";i:2;}', 'yes'),
(125, 'can_compress_scripts', '1', 'yes'),
(138, 'theme_mods_twentysixteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1462924060;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(139, 'current_theme', 'FoundationPress', 'yes'),
(140, 'theme_mods_onceuponawatch', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:8:"headmenu";i:7;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1463590136;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:8:{i:0;s:25:"woocommerce_widget_cart-2";i:1;s:33:"woocommerce_layered_nav_filters-2";i:2;s:25:"woocommerce_layered_nav-2";i:3;s:25:"woocommerce_layered_nav-3";i:4;s:25:"woocommerce_layered_nav-4";i:5;s:26:"woocommerce_price_filter-2";i:6;s:32:"woocommerce_product_categories-2";i:7;s:22:"woocommerce_products-2";}s:15:"sidebar-widgets";a:2:{i:0;s:10:"archives-2";i:1;s:12:"categories-2";}s:14:"footer-widgets";N;}}}', 'yes'),
(141, 'theme_switched', '', 'yes'),
(142, 'recently_activated', 'a:0:{}', 'yes'),
(183, 'woocommerce_default_country', 'FR', 'yes'),
(184, 'woocommerce_allowed_countries', 'all', 'yes'),
(185, 'woocommerce_specific_allowed_countries', '', 'yes'),
(186, 'woocommerce_default_customer_address', 'geolocation', 'yes'),
(187, 'woocommerce_demo_store', 'no', 'yes'),
(188, 'woocommerce_demo_store_notice', 'This is a demo store for testing purposes &mdash; no orders shall be fulfilled.', 'no'),
(189, 'woocommerce_currency', 'EUR', 'yes'),
(190, 'woocommerce_currency_pos', 'right', 'yes'),
(191, 'woocommerce_price_thousand_sep', '', 'yes'),
(192, 'woocommerce_price_decimal_sep', ',', 'yes'),
(193, 'woocommerce_price_num_decimals', '2', 'yes'),
(194, 'woocommerce_weight_unit', 'kg', 'yes'),
(195, 'woocommerce_dimension_unit', 'cm', 'yes'),
(196, 'woocommerce_enable_review_rating', 'yes', 'no'),
(197, 'woocommerce_review_rating_required', 'yes', 'no'),
(198, 'woocommerce_review_rating_verification_label', 'yes', 'no'),
(199, 'woocommerce_review_rating_verification_required', 'no', 'no'),
(200, 'woocommerce_shop_page_id', '4', 'yes'),
(201, 'woocommerce_shop_page_display', 'subcategories', 'yes'),
(202, 'woocommerce_category_archive_display', 'subcategories', 'yes'),
(203, 'woocommerce_default_catalog_orderby', 'menu_order', 'yes'),
(204, 'woocommerce_cart_redirect_after_add', 'no', 'yes'),
(205, 'woocommerce_enable_ajax_add_to_cart', 'yes', 'yes'),
(206, 'shop_catalog_image_size', 'a:3:{s:5:"width";s:3:"300";s:6:"height";s:3:"300";s:4:"crop";i:1;}', 'yes'),
(207, 'shop_single_image_size', 'a:3:{s:5:"width";s:0:"";s:6:"height";s:0:"";s:4:"crop";i:0;}', 'yes'),
(208, 'shop_thumbnail_image_size', 'a:3:{s:5:"width";s:3:"180";s:6:"height";s:3:"180";s:4:"crop";i:1;}', 'yes'),
(209, 'woocommerce_enable_lightbox', 'yes', 'yes'),
(210, 'woocommerce_manage_stock', 'yes', 'yes'),
(211, 'woocommerce_hold_stock_minutes', '60', 'no'),
(212, 'woocommerce_notify_low_stock', 'yes', 'no'),
(213, 'woocommerce_notify_no_stock', 'yes', 'no'),
(214, 'woocommerce_stock_email_recipient', 'alexandre.kong@gmail.com', 'no'),
(215, 'woocommerce_notify_low_stock_amount', '2', 'no'),
(216, 'woocommerce_notify_no_stock_amount', '0', 'no'),
(217, 'woocommerce_hide_out_of_stock_items', 'no', 'yes'),
(218, 'woocommerce_stock_format', '', 'yes'),
(219, 'woocommerce_file_download_method', 'force', 'no'),
(220, 'woocommerce_downloads_require_login', 'no', 'no'),
(221, 'woocommerce_downloads_grant_access_after_payment', 'yes', 'no'),
(222, 'woocommerce_calc_taxes', 'no', 'yes'),
(223, 'woocommerce_prices_include_tax', 'no', 'yes'),
(224, 'woocommerce_tax_based_on', 'shipping', 'yes'),
(225, 'woocommerce_shipping_tax_class', 'title', 'yes'),
(226, 'woocommerce_tax_round_at_subtotal', 'no', 'yes'),
(227, 'woocommerce_tax_classes', 'Reduced Rate\nZero Rate', 'yes'),
(228, 'woocommerce_tax_display_shop', 'excl', 'yes'),
(229, 'woocommerce_tax_display_cart', 'excl', 'no'),
(230, 'woocommerce_price_display_suffix', '', 'yes'),
(231, 'woocommerce_tax_total_display', 'itemized', 'no'),
(232, 'woocommerce_enable_coupons', 'yes', 'no'),
(233, 'woocommerce_calc_discounts_sequentially', 'no', 'no'),
(234, 'woocommerce_enable_guest_checkout', 'yes', 'no'),
(235, 'woocommerce_force_ssl_checkout', 'no', 'yes'),
(236, 'woocommerce_unforce_ssl_checkout', 'no', 'yes'),
(237, 'woocommerce_cart_page_id', '5', 'yes'),
(238, 'woocommerce_checkout_page_id', '6', 'yes'),
(239, 'woocommerce_terms_page_id', '', 'no'),
(240, 'woocommerce_checkout_pay_endpoint', 'order-pay', 'yes'),
(241, 'woocommerce_checkout_order_received_endpoint', 'order-received', 'yes'),
(242, 'woocommerce_myaccount_add_payment_method_endpoint', 'add-payment-method', 'yes'),
(243, 'woocommerce_calc_shipping', 'no', 'yes'),
(244, 'woocommerce_enable_shipping_calc', 'yes', 'no'),
(245, 'woocommerce_shipping_cost_requires_address', 'no', 'no'),
(246, 'woocommerce_ship_to_destination', 'billing', 'no'),
(247, 'woocommerce_ship_to_countries', '', 'yes'),
(248, 'woocommerce_specific_ship_to_countries', '', 'yes'),
(249, 'woocommerce_myaccount_page_id', '7', 'yes'),
(250, 'woocommerce_myaccount_view_order_endpoint', 'view-order', 'yes'),
(251, 'woocommerce_myaccount_edit_account_endpoint', 'edit-account', 'yes'),
(252, 'woocommerce_myaccount_edit_address_endpoint', 'edit-address', 'yes'),
(253, 'woocommerce_myaccount_lost_password_endpoint', 'lost-password', 'yes'),
(254, 'woocommerce_logout_endpoint', 'customer-logout', 'yes'),
(255, 'woocommerce_enable_signup_and_login_from_checkout', 'yes', 'no'),
(256, 'woocommerce_enable_myaccount_registration', 'no', 'no'),
(257, 'woocommerce_enable_checkout_login_reminder', 'yes', 'no'),
(258, 'woocommerce_registration_generate_username', 'yes', 'no'),
(259, 'woocommerce_registration_generate_password', 'no', 'no'),
(260, 'woocommerce_email_from_name', 'Once Upon a Watch', 'no'),
(261, 'woocommerce_email_from_address', 'alexandre.kong@gmail.com', 'no'),
(262, 'woocommerce_email_header_image', '', 'no'),
(263, 'woocommerce_email_footer_text', 'Once Upon a Watch - Powered by WooCommerce', 'no'),
(264, 'woocommerce_email_base_color', '#557da1', 'no'),
(265, 'woocommerce_email_background_color', '#f5f5f5', 'no'),
(266, 'woocommerce_email_body_background_color', '#fdfdfd', 'no'),
(267, 'woocommerce_email_text_color', '#505050', 'no'),
(268, 'woocommerce_api_enabled', 'yes', 'yes'),
(270, 'woocommerce_admin_notices', 'a:0:{}', 'yes'),
(273, 'woocommerce_db_version', '2.5.5', 'yes'),
(274, 'woocommerce_version', '2.5.5', 'yes'),
(277, 'widget_woocommerce_widget_cart', 'a:2:{i:2;a:2:{s:5:"title";s:6:"Panier";s:13:"hide_if_empty";i:0;}s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(278, 'widget_woocommerce_layered_nav_filters', 'a:2:{i:2;a:1:{s:5:"title";s:14:"Filtres actifs";}s:12:"_multiwidget";i:1;}', 'yes'),
(279, 'widget_woocommerce_layered_nav', 'a:3:{i:2;a:4:{s:5:"title";s:11:"Filtré par";s:9:"attribute";s:7:"couleur";s:12:"display_type";s:4:"list";s:10:"query_type";s:3:"and";}i:3;a:4:{s:5:"title";s:9:"Couleur :";s:9:"attribute";s:7:"couleur";s:12:"display_type";s:8:"dropdown";s:10:"query_type";s:3:"and";}s:12:"_multiwidget";i:1;}', 'yes'),
(280, 'widget_woocommerce_price_filter', 'a:2:{i:2;a:1:{s:5:"title";s:16:"Filtrer par prix";}s:12:"_multiwidget";i:1;}', 'yes'),
(281, 'widget_woocommerce_product_categories', 'a:2:{i:2;a:7:{s:5:"title";s:22:"Catégories du produit";s:7:"orderby";s:4:"name";s:8:"dropdown";i:1;s:5:"count";i:1;s:12:"hierarchical";i:1;s:18:"show_children_only";i:1;s:10:"hide_empty";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(282, 'widget_woocommerce_product_search', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(283, 'widget_woocommerce_product_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(284, 'widget_woocommerce_products', 'a:2:{i:2;a:7:{s:5:"title";s:8:"Produits";s:6:"number";i:5;s:4:"show";s:0:"";s:7:"orderby";s:4:"date";s:5:"order";s:4:"desc";s:9:"hide_free";i:0;s:11:"show_hidden";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(285, 'widget_woocommerce_recent_reviews', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(286, 'widget_woocommerce_recently_viewed_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(287, 'widget_woocommerce_top_rated_products', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(290, 'woocommerce_meta_box_errors', 'a:0:{}', 'yes'),
(298, 'woocommerce_paypal_settings', 'a:2:{s:7:"enabled";s:3:"yes";s:5:"email";s:26:"mr.alexandrekong@gmail.com";}', 'yes'),
(299, 'woocommerce_cheque_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(300, 'woocommerce_cod_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(301, 'woocommerce_bacs_settings', 'a:1:{s:7:"enabled";s:2:"no";}', 'yes'),
(307, 'woocommerce_permalinks', 'a:4:{s:13:"category_base";s:0:"";s:8:"tag_base";s:0:"";s:14:"attribute_base";s:0:"";s:12:"product_base";s:0:"";}', 'yes'),
(372, 'asl_version', '4620', 'yes'),
(375, 'widget_ajaxsearchlitewidget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(377, 'asl_debug_data', 'a:2:{s:11:"asl_options";a:134:{s:5:"theme";s:9:"underline";s:20:"override_search_form";s:1:"0";s:14:"triggeronclick";s:1:"1";s:23:"trigger_on_facet_change";s:1:"1";s:15:"redirectonclick";s:1:"0";s:17:"redirect_click_to";s:12:"results_page";s:17:"redirect_on_enter";s:1:"0";s:17:"redirect_enter_to";s:12:"results_page";s:13:"triggerontype";s:1:"1";s:13:"searchinposts";s:1:"1";s:13:"searchinpages";s:1:"1";s:11:"customtypes";s:79:"product_variation|product|shop_webhook|shop_order|shop_order_refund|shop_coupon";s:13:"searchintitle";s:1:"1";s:15:"searchincontent";s:1:"1";s:15:"searchinexcerpt";s:1:"1";s:12:"customfields";s:0:"";s:24:"override_default_results";s:1:"0";s:9:"exactonly";s:1:"0";s:13:"searchinterms";s:1:"0";s:9:"charcount";s:1:"3";s:10:"maxresults";s:2:"10";s:10:"itemscount";s:1:"4";s:16:"resultitemheight";s:4:"70px";s:15:"orderby_primary";s:14:"relevance DESC";s:17:"orderby_secondary";s:9:"date DESC";s:11:"show_images";s:1:"1";s:18:"image_transparency";i:1;s:14:"image_bg_color";s:7:"#FFFFFF";s:11:"image_width";s:2:"70";s:12:"image_height";s:2:"70";s:19:"image_crop_location";s:1:"c";s:27:"image_crop_location_selects";a:9:{i:0;a:2:{s:6:"option";s:13:"In the center";s:5:"value";s:1:"c";}i:1;a:2:{s:6:"option";s:9:"Align top";s:5:"value";s:1:"t";}i:2;a:2:{s:6:"option";s:15:"Align top right";s:5:"value";s:2:"tr";}i:3;a:2:{s:6:"option";s:14:"Align top left";s:5:"value";s:2:"tl";}i:4;a:2:{s:6:"option";s:12:"Align bottom";s:5:"value";s:1:"b";}i:5;a:2:{s:6:"option";s:18:"Align bottom right";s:5:"value";s:2:"br";}i:6;a:2:{s:6:"option";s:17:"Align bottom left";s:5:"value";s:2:"bl";}i:7;a:2:{s:6:"option";s:10:"Align left";s:5:"value";s:1:"l";}i:8;a:2:{s:6:"option";s:11:"Align right";s:5:"value";s:1:"r";}}s:13:"image_sources";a:7:{i:0;a:2:{s:6:"option";s:14:"Featured image";s:5:"value";s:8:"featured";}i:1;a:2:{s:6:"option";s:12:"Post Content";s:5:"value";s:7:"content";}i:2;a:2:{s:6:"option";s:12:"Post Excerpt";s:5:"value";s:7:"excerpt";}i:3;a:2:{s:6:"option";s:12:"Custom field";s:5:"value";s:6:"custom";}i:4;a:2:{s:6:"option";s:15:"Page Screenshot";s:5:"value";s:10:"screenshot";}i:5;a:2:{s:6:"option";s:13:"Default image";s:5:"value";s:7:"default";}i:6;a:2:{s:6:"option";s:8:"Disabled";s:5:"value";s:8:"disabled";}}s:13:"image_source1";s:8:"featured";s:13:"image_source2";s:7:"content";s:13:"image_source3";s:7:"excerpt";s:13:"image_source4";s:6:"custom";s:13:"image_source5";s:7:"default";s:13:"image_default";s:88:"http://localhost:8888/onceuponawatch/wp-content/plugins/ajax-search-lite/img/default.jpg";s:18:"image_custom_field";s:0:"";s:12:"use_timthumb";i:1;s:29:"show_frontend_search_settings";s:1:"1";s:16:"showexactmatches";s:1:"1";s:17:"showsearchinposts";s:1:"1";s:17:"showsearchinpages";s:1:"1";s:17:"showsearchintitle";s:1:"1";s:19:"showsearchincontent";s:1:"1";s:15:"showcustomtypes";s:0:"";s:20:"showsearchincomments";i:1;s:19:"showsearchinexcerpt";i:1;s:19:"showsearchinbpusers";i:0;s:20:"showsearchinbpgroups";i:0;s:20:"showsearchinbpforums";i:0;s:16:"exactmatchestext";s:19:"Mot exact seulement";s:17:"searchinpoststext";s:14:"Dans les posts";s:17:"searchinpagestext";s:14:"Dans les pages";s:17:"searchintitletext";s:13:"Dans le titre";s:19:"searchincontenttext";s:15:"Dans le contenu";s:20:"searchincommentstext";s:18:"Search in comments";s:19:"searchinexcerpttext";s:17:"Search in excerpt";s:19:"searchinbpuserstext";s:15:"Search in users";s:20:"searchinbpgroupstext";s:16:"Search in groups";s:20:"searchinbpforumstext";s:16:"Search in forums";s:22:"showsearchincategories";s:1:"1";s:17:"showuncategorised";s:1:"1";s:20:"exsearchincategories";s:0:"";s:26:"exsearchincategoriesheight";i:200;s:22:"showsearchintaxonomies";i:1;s:9:"showterms";s:0:"";s:23:"showseparatefilterboxes";i:1;s:24:"exsearchintaxonomiestext";s:9:"Filter by";s:24:"exsearchincategoriestext";s:21:"Trier par catégories";s:9:"box_width";s:4:"100%";s:10:"box_margin";s:22:"||0px||0px||0px||0px||";s:15:"resultstype_def";a:4:{i:0;a:2:{s:6:"option";s:16:"Vertical Results";s:5:"value";s:8:"vertical";}i:1;a:2:{s:6:"option";s:18:"Horizontal Results";s:5:"value";s:10:"horizontal";}i:2;a:2:{s:6:"option";s:16:"Isotopic Results";s:5:"value";s:8:"isotopic";}i:3;a:2:{s:6:"option";s:22:"Polaroid style Results";s:5:"value";s:8:"polaroid";}}s:11:"resultstype";s:8:"vertical";s:19:"resultsposition_def";a:2:{i:0;a:2:{s:6:"option";s:20:"Hover - over content";s:5:"value";s:5:"hover";}i:1;a:2:{s:6:"option";s:22:"Block - pushes content";s:5:"value";s:5:"block";}}s:15:"resultsposition";s:5:"hover";s:16:"resultsmargintop";s:4:"12px";s:17:"defaultsearchtext";s:27:"Rechercher sur le site ....";s:15:"showmoreresults";s:1:"0";s:19:"showmoreresultstext";s:18:"Plus de résultats";s:12:"showmorefont";s:151:"font-weight:normal;font-family:--g--Open Sans;color:rgba(5, 94, 148, 1);font-size:12px;line-height:15px;text-shadow:0px 0px 0px rgba(255, 255, 255, 0);";s:17:"scroll_to_results";s:1:"0";s:19:"resultareaclickable";s:1:"1";s:23:"close_on_document_click";s:1:"1";s:15:"show_close_icon";s:1:"1";s:10:"showauthor";s:1:"0";s:8:"showdate";s:1:"0";s:15:"showdescription";s:1:"1";s:17:"descriptionlength";s:3:"100";s:19:"description_context";s:1:"0";s:13:"noresultstext";s:17:"Pas de résultats";s:14:"didyoumeantext";s:19:"Vous vouliez dire :";s:12:"kw_highlight";s:1:"0";s:24:"kw_highlight_whole_words";s:1:"1";s:15:"highlight_color";s:20:"rgba(217, 49, 43, 1)";s:18:"highlight_bg_color";s:22:"rgba(238, 238, 238, 1)";s:12:"autocomplete";s:1:"0";s:14:"kw_suggestions";s:1:"0";s:9:"kw_length";s:2:"60";s:8:"kw_count";s:2:"10";s:14:"kw_google_lang";s:2:"fr";s:13:"kw_exceptions";s:0:"";s:12:"shortcode_op";s:6:"remove";s:16:"striptagsexclude";s:0:"";s:12:"runshortcode";i:1;s:14:"stripshortcode";i:0;s:19:"pageswithcategories";i:0;s:14:"titlefield_def";a:2:{i:0;a:2:{s:6:"option";s:10:"Post Title";s:5:"value";i:0;}i:1;a:2:{s:6:"option";s:12:"Post Excerpt";s:5:"value";i:1;}}s:10:"titlefield";s:1:"0";s:20:"descriptionfield_def";a:3:{i:0;a:2:{s:6:"option";s:16:"Post Description";s:5:"value";i:0;}i:1;a:2:{s:6:"option";s:12:"Post Excerpt";s:5:"value";i:1;}i:2;a:2:{s:6:"option";s:10:"Post Title";s:5:"value";i:2;}}s:16:"descriptionfield";s:1:"0";s:17:"excludecategories";s:0:"";s:12:"excludeposts";s:0:"";s:16:"exclude_term_ids";s:0:"";s:18:"wpml_compatibility";s:1:"1";s:21:"classname-customtypes";s:23:"wpdreamsCustomPostTypes";s:22:"classname-customfields";s:20:"wpdreamsCustomFields";s:10:"asl_submit";s:1:"1";s:10:"submit_asl";s:13:"Save options!";s:25:"classname-showcustomtypes";s:31:"wpdreamsCustomPostTypesEditable";s:30:"classname-exsearchincategories";s:18:"wpdreamsCategories";s:7:"topleft";s:3:"0px";s:11:"bottomright";s:3:"0px";s:8:"topright";s:3:"0px";s:10:"bottomleft";s:3:"0px";s:27:"classname-excludecategories";s:18:"wpdreamsCategories";s:10:"sett_tabid";s:3:"103";s:20:"selected-customtypes";a:6:{i:0;s:17:"product_variation";i:1;s:7:"product";i:2;s:12:"shop_webhook";i:3;s:10:"shop_order";i:4;s:17:"shop_order_refund";i:5;s:11:"shop_coupon";}s:21:"selected-customfields";N;s:24:"selected-showcustomtypes";N;s:29:"selected-exsearchincategories";N;s:26:"selected-excludecategories";N;}s:7:"queries";a:5:{i:0;a:4:{s:6:"phrase";s:6:"montre";s:7:"options";a:17:{s:15:"qtranslate_lang";s:1:"0";s:11:"set_intitle";b:1;s:13:"set_incontent";b:1;s:13:"set_inexcerpt";b:1;s:11:"set_inposts";b:1;s:11:"set_inpages";b:1;s:9:"customset";a:6:{i:0;s:17:"product_variation";i:1;s:7:"product";i:2;s:12:"shop_webhook";i:3;s:10:"shop_order";i:4;s:17:"shop_order_refund";i:5;s:11:"shop_coupon";}s:11:"categoryset";a:1:{i:0;s:1:"6";}s:13:"set_exactonly";b:0;s:14:"set_incomments";b:0;s:13:"searchinterms";b:0;s:13:"set_inbpusers";b:0;s:14:"set_inbpgroups";b:0;s:14:"set_inbpforums";b:0;s:10:"maxresults";s:2:"10";s:8:"do_group";b:1;s:7:"termset";a:0:{}}s:5:"query";s:1788:"\r\n    		SELECT \r\n          wp_posts.post_title as title,\r\n          wp_posts.ID as id,\r\n          wp_posts.post_date as date,               \r\n          wp_posts.post_content as content,\r\n          \'\' as excerpt,\r\n          \'pagepost\' as content_type,\r\n	        (SELECT\r\n	            wp_users.display_name as author\r\n	            FROM wp_users\r\n	            WHERE wp_users.ID = wp_posts.post_author\r\n	        ) as author,\r\n          \'\' as ttid,\r\n          wp_posts.post_type as post_type,\r\n          ((case when\r\n                (wp_posts.post_title LIKE \'%montre%\')\r\n                 then 10 else 0 end) + (case when\r\n                  (wp_posts.post_title LIKE \'%montre%\')\r\n                   then 10 else 0 end) + (case when\r\n                    (wp_posts.post_content LIKE \'%montre%\')\r\n                     then 8 else 0 end) + (case when\r\n                (wp_posts.post_content LIKE \'%montre%\')\r\n                 then 8 else 0 end) + (case when\r\n                    (wp_posts.post_excerpt LIKE \'%montre%\')\r\n                     then 7 else 0 end) + (case when\r\n                (wp_posts.post_excerpt LIKE \'%montre%\')\r\n                 then 7 else 0 end)) as relevance\r\n    		FROM wp_posts\r\n        \r\n        \r\n    	WHERE\r\n                (wp_posts.post_type IN (\'post\',\'page\',\'product_variation\',\'product\',\'shop_webhook\',\'shop_order\',\'shop_order_refund\',\'shop_coupon\') )\r\n            AND ( wp_posts.post_status = \'publish\')\r\n            AND (1)\r\n            AND (( wp_posts.post_title LIKE \'%montre%\' ) OR ( wp_posts.post_content LIKE \'%montre%\' ) OR ( wp_posts.post_excerpt LIKE \'%montre%\' ))\r\n            AND (wp_posts.ID NOT IN (-55))\r\n            AND ( (1) )\r\n        GROUP BY\r\n          wp_posts.ID\r\n        ORDER BY\r\n        	relevance DESC, date DESC, id DESC\r\n        LIMIT 10";s:7:"results";i:3;}i:1;a:4:{s:6:"phrase";s:7:"bonjour";s:7:"options";a:17:{s:15:"qtranslate_lang";s:1:"0";s:11:"set_intitle";b:1;s:13:"set_incontent";b:1;s:13:"set_inexcerpt";b:1;s:11:"set_inposts";b:1;s:11:"set_inpages";b:1;s:9:"customset";a:6:{i:0;s:17:"product_variation";i:1;s:7:"product";i:2;s:12:"shop_webhook";i:3;s:10:"shop_order";i:4;s:17:"shop_order_refund";i:5;s:11:"shop_coupon";}s:11:"categoryset";a:1:{i:0;s:1:"6";}s:13:"set_exactonly";b:0;s:14:"set_incomments";b:0;s:13:"searchinterms";b:0;s:13:"set_inbpusers";b:0;s:14:"set_inbpgroups";b:0;s:14:"set_inbpforums";b:0;s:10:"maxresults";s:2:"10";s:8:"do_group";b:1;s:7:"termset";a:0:{}}s:5:"query";s:1797:"\r\n    		SELECT \r\n          wp_posts.post_title as title,\r\n          wp_posts.ID as id,\r\n          wp_posts.post_date as date,               \r\n          wp_posts.post_content as content,\r\n          \'\' as excerpt,\r\n          \'pagepost\' as content_type,\r\n	        (SELECT\r\n	            wp_users.display_name as author\r\n	            FROM wp_users\r\n	            WHERE wp_users.ID = wp_posts.post_author\r\n	        ) as author,\r\n          \'\' as ttid,\r\n          wp_posts.post_type as post_type,\r\n          ((case when\r\n                (wp_posts.post_title LIKE \'%bonjour%\')\r\n                 then 10 else 0 end) + (case when\r\n                  (wp_posts.post_title LIKE \'%bonjour%\')\r\n                   then 10 else 0 end) + (case when\r\n                    (wp_posts.post_content LIKE \'%bonjour%\')\r\n                     then 8 else 0 end) + (case when\r\n                (wp_posts.post_content LIKE \'%bonjour%\')\r\n                 then 8 else 0 end) + (case when\r\n                    (wp_posts.post_excerpt LIKE \'%bonjour%\')\r\n                     then 7 else 0 end) + (case when\r\n                (wp_posts.post_excerpt LIKE \'%bonjour%\')\r\n                 then 7 else 0 end)) as relevance\r\n    		FROM wp_posts\r\n        \r\n        \r\n    	WHERE\r\n                (wp_posts.post_type IN (\'post\',\'page\',\'product_variation\',\'product\',\'shop_webhook\',\'shop_order\',\'shop_order_refund\',\'shop_coupon\') )\r\n            AND ( wp_posts.post_status = \'publish\')\r\n            AND (1)\r\n            AND (( wp_posts.post_title LIKE \'%bonjour%\' ) OR ( wp_posts.post_content LIKE \'%bonjour%\' ) OR ( wp_posts.post_excerpt LIKE \'%bonjour%\' ))\r\n            AND (wp_posts.ID NOT IN (-55))\r\n            AND ( (1) )\r\n        GROUP BY\r\n          wp_posts.ID\r\n        ORDER BY\r\n        	relevance DESC, date DESC, id DESC\r\n        LIMIT 10";s:7:"results";i:1;}i:2;a:4:{s:6:"phrase";s:5:"rolex";s:7:"options";a:17:{s:15:"qtranslate_lang";s:1:"0";s:11:"set_intitle";b:1;s:13:"set_incontent";b:1;s:13:"set_inexcerpt";b:1;s:11:"set_inposts";b:1;s:11:"set_inpages";b:1;s:9:"customset";a:6:{i:0;s:17:"product_variation";i:1;s:7:"product";i:2;s:12:"shop_webhook";i:3;s:10:"shop_order";i:4;s:17:"shop_order_refund";i:5;s:11:"shop_coupon";}s:11:"categoryset";a:1:{i:0;s:1:"6";}s:13:"set_exactonly";b:0;s:14:"set_incomments";b:0;s:13:"searchinterms";b:0;s:13:"set_inbpusers";b:0;s:14:"set_inbpgroups";b:0;s:14:"set_inbpforums";b:0;s:10:"maxresults";s:2:"10";s:8:"do_group";b:1;s:7:"termset";a:0:{}}s:5:"query";s:1779:"\r\n    		SELECT \r\n          wp_posts.post_title as title,\r\n          wp_posts.ID as id,\r\n          wp_posts.post_date as date,               \r\n          wp_posts.post_content as content,\r\n          \'\' as excerpt,\r\n          \'pagepost\' as content_type,\r\n	        (SELECT\r\n	            wp_users.display_name as author\r\n	            FROM wp_users\r\n	            WHERE wp_users.ID = wp_posts.post_author\r\n	        ) as author,\r\n          \'\' as ttid,\r\n          wp_posts.post_type as post_type,\r\n          ((case when\r\n                (wp_posts.post_title LIKE \'%rolex%\')\r\n                 then 10 else 0 end) + (case when\r\n                  (wp_posts.post_title LIKE \'%rolex%\')\r\n                   then 10 else 0 end) + (case when\r\n                    (wp_posts.post_content LIKE \'%rolex%\')\r\n                     then 8 else 0 end) + (case when\r\n                (wp_posts.post_content LIKE \'%rolex%\')\r\n                 then 8 else 0 end) + (case when\r\n                    (wp_posts.post_excerpt LIKE \'%rolex%\')\r\n                     then 7 else 0 end) + (case when\r\n                (wp_posts.post_excerpt LIKE \'%rolex%\')\r\n                 then 7 else 0 end)) as relevance\r\n    		FROM wp_posts\r\n        \r\n        \r\n    	WHERE\r\n                (wp_posts.post_type IN (\'post\',\'page\',\'product_variation\',\'product\',\'shop_webhook\',\'shop_order\',\'shop_order_refund\',\'shop_coupon\') )\r\n            AND ( wp_posts.post_status = \'publish\')\r\n            AND (1)\r\n            AND (( wp_posts.post_title LIKE \'%rolex%\' ) OR ( wp_posts.post_content LIKE \'%rolex%\' ) OR ( wp_posts.post_excerpt LIKE \'%rolex%\' ))\r\n            AND (wp_posts.ID NOT IN (-55))\r\n            AND ( (1) )\r\n        GROUP BY\r\n          wp_posts.ID\r\n        ORDER BY\r\n        	relevance DESC, date DESC, id DESC\r\n        LIMIT 10";s:7:"results";i:3;}i:3;a:4:{s:6:"phrase";s:6:"montre";s:7:"options";a:17:{s:15:"qtranslate_lang";s:1:"0";s:11:"set_intitle";b:1;s:13:"set_incontent";b:1;s:13:"set_inexcerpt";b:1;s:11:"set_inposts";b:1;s:11:"set_inpages";b:1;s:9:"customset";a:6:{i:0;s:17:"product_variation";i:1;s:7:"product";i:2;s:12:"shop_webhook";i:3;s:10:"shop_order";i:4;s:17:"shop_order_refund";i:5;s:11:"shop_coupon";}s:11:"categoryset";a:1:{i:0;s:1:"6";}s:13:"set_exactonly";b:0;s:14:"set_incomments";b:0;s:13:"searchinterms";b:0;s:13:"set_inbpusers";b:0;s:14:"set_inbpgroups";b:0;s:14:"set_inbpforums";b:0;s:10:"maxresults";s:2:"10";s:8:"do_group";b:1;s:7:"termset";a:0:{}}s:5:"query";s:1788:"\r\n    		SELECT \r\n          wp_posts.post_title as title,\r\n          wp_posts.ID as id,\r\n          wp_posts.post_date as date,               \r\n          wp_posts.post_content as content,\r\n          \'\' as excerpt,\r\n          \'pagepost\' as content_type,\r\n	        (SELECT\r\n	            wp_users.display_name as author\r\n	            FROM wp_users\r\n	            WHERE wp_users.ID = wp_posts.post_author\r\n	        ) as author,\r\n          \'\' as ttid,\r\n          wp_posts.post_type as post_type,\r\n          ((case when\r\n                (wp_posts.post_title LIKE \'%montre%\')\r\n                 then 10 else 0 end) + (case when\r\n                  (wp_posts.post_title LIKE \'%montre%\')\r\n                   then 10 else 0 end) + (case when\r\n                    (wp_posts.post_content LIKE \'%montre%\')\r\n                     then 8 else 0 end) + (case when\r\n                (wp_posts.post_content LIKE \'%montre%\')\r\n                 then 8 else 0 end) + (case when\r\n                    (wp_posts.post_excerpt LIKE \'%montre%\')\r\n                     then 7 else 0 end) + (case when\r\n                (wp_posts.post_excerpt LIKE \'%montre%\')\r\n                 then 7 else 0 end)) as relevance\r\n    		FROM wp_posts\r\n        \r\n        \r\n    	WHERE\r\n                (wp_posts.post_type IN (\'post\',\'page\',\'product_variation\',\'product\',\'shop_webhook\',\'shop_order\',\'shop_order_refund\',\'shop_coupon\') )\r\n            AND ( wp_posts.post_status = \'publish\')\r\n            AND (1)\r\n            AND (( wp_posts.post_title LIKE \'%montre%\' ) OR ( wp_posts.post_content LIKE \'%montre%\' ) OR ( wp_posts.post_excerpt LIKE \'%montre%\' ))\r\n            AND (wp_posts.ID NOT IN (-55))\r\n            AND ( (1) )\r\n        GROUP BY\r\n          wp_posts.ID\r\n        ORDER BY\r\n        	relevance DESC, date DESC, id DESC\r\n        LIMIT 10";s:7:"results";i:3;}i:4;a:4:{s:6:"phrase";s:6:"montre";s:7:"options";a:17:{s:15:"qtranslate_lang";s:1:"0";s:11:"set_intitle";b:1;s:13:"set_incontent";b:1;s:13:"set_inexcerpt";b:1;s:11:"set_inposts";b:1;s:11:"set_inpages";b:1;s:9:"customset";a:6:{i:0;s:17:"product_variation";i:1;s:7:"product";i:2;s:12:"shop_webhook";i:3;s:10:"shop_order";i:4;s:17:"shop_order_refund";i:5;s:11:"shop_coupon";}s:11:"categoryset";a:1:{i:0;s:1:"6";}s:13:"set_exactonly";b:0;s:14:"set_incomments";b:0;s:13:"searchinterms";b:0;s:13:"set_inbpusers";b:0;s:14:"set_inbpgroups";b:0;s:14:"set_inbpforums";b:0;s:10:"maxresults";s:2:"10";s:8:"do_group";b:1;s:7:"termset";a:0:{}}s:5:"query";s:1788:"\r\n    		SELECT \r\n          wp_posts.post_title as title,\r\n          wp_posts.ID as id,\r\n          wp_posts.post_date as date,               \r\n          wp_posts.post_content as content,\r\n          \'\' as excerpt,\r\n          \'pagepost\' as content_type,\r\n	        (SELECT\r\n	            wp_users.display_name as author\r\n	            FROM wp_users\r\n	            WHERE wp_users.ID = wp_posts.post_author\r\n	        ) as author,\r\n          \'\' as ttid,\r\n          wp_posts.post_type as post_type,\r\n          ((case when\r\n                (wp_posts.post_title LIKE \'%montre%\')\r\n                 then 10 else 0 end) + (case when\r\n                  (wp_posts.post_title LIKE \'%montre%\')\r\n                   then 10 else 0 end) + (case when\r\n                    (wp_posts.post_content LIKE \'%montre%\')\r\n                     then 8 else 0 end) + (case when\r\n                (wp_posts.post_content LIKE \'%montre%\')\r\n                 then 8 else 0 end) + (case when\r\n                    (wp_posts.post_excerpt LIKE \'%montre%\')\r\n                     then 7 else 0 end) + (case when\r\n                (wp_posts.post_excerpt LIKE \'%montre%\')\r\n                 then 7 else 0 end)) as relevance\r\n    		FROM wp_posts\r\n        \r\n        \r\n    	WHERE\r\n                (wp_posts.post_type IN (\'post\',\'page\',\'product_variation\',\'product\',\'shop_webhook\',\'shop_order\',\'shop_order_refund\',\'shop_coupon\') )\r\n            AND ( wp_posts.post_status = \'publish\')\r\n            AND (1)\r\n            AND (( wp_posts.post_title LIKE \'%montre%\' ) OR ( wp_posts.post_content LIKE \'%montre%\' ) OR ( wp_posts.post_excerpt LIKE \'%montre%\' ))\r\n            AND (wp_posts.ID NOT IN (-55))\r\n            AND ( (1) )\r\n        GROUP BY\r\n          wp_posts.ID\r\n        ORDER BY\r\n        	relevance DESC, date DESC, id DESC\r\n        LIMIT 10";s:7:"results";i:3;}}}', 'yes'),
(416, 'asl_options', 'a:134:{s:5:"theme";s:9:"underline";s:20:"override_search_form";s:1:"0";s:14:"triggeronclick";s:1:"1";s:23:"trigger_on_facet_change";s:1:"1";s:15:"redirectonclick";s:1:"0";s:17:"redirect_click_to";s:12:"results_page";s:17:"redirect_on_enter";s:1:"0";s:17:"redirect_enter_to";s:12:"results_page";s:13:"triggerontype";s:1:"1";s:13:"searchinposts";s:1:"1";s:13:"searchinpages";s:1:"1";s:11:"customtypes";s:79:"product_variation|product|shop_webhook|shop_order|shop_order_refund|shop_coupon";s:13:"searchintitle";s:1:"1";s:15:"searchincontent";s:1:"1";s:15:"searchinexcerpt";s:1:"1";s:12:"customfields";s:0:"";s:24:"override_default_results";s:1:"0";s:9:"exactonly";s:1:"0";s:13:"searchinterms";s:1:"0";s:9:"charcount";s:1:"3";s:10:"maxresults";s:2:"10";s:10:"itemscount";s:1:"4";s:16:"resultitemheight";s:4:"70px";s:15:"orderby_primary";s:14:"relevance DESC";s:17:"orderby_secondary";s:9:"date DESC";s:11:"show_images";s:1:"1";s:18:"image_transparency";i:1;s:14:"image_bg_color";s:7:"#FFFFFF";s:11:"image_width";s:2:"70";s:12:"image_height";s:2:"70";s:19:"image_crop_location";s:1:"c";s:27:"image_crop_location_selects";a:9:{i:0;a:2:{s:6:"option";s:13:"In the center";s:5:"value";s:1:"c";}i:1;a:2:{s:6:"option";s:9:"Align top";s:5:"value";s:1:"t";}i:2;a:2:{s:6:"option";s:15:"Align top right";s:5:"value";s:2:"tr";}i:3;a:2:{s:6:"option";s:14:"Align top left";s:5:"value";s:2:"tl";}i:4;a:2:{s:6:"option";s:12:"Align bottom";s:5:"value";s:1:"b";}i:5;a:2:{s:6:"option";s:18:"Align bottom right";s:5:"value";s:2:"br";}i:6;a:2:{s:6:"option";s:17:"Align bottom left";s:5:"value";s:2:"bl";}i:7;a:2:{s:6:"option";s:10:"Align left";s:5:"value";s:1:"l";}i:8;a:2:{s:6:"option";s:11:"Align right";s:5:"value";s:1:"r";}}s:13:"image_sources";a:7:{i:0;a:2:{s:6:"option";s:14:"Featured image";s:5:"value";s:8:"featured";}i:1;a:2:{s:6:"option";s:12:"Post Content";s:5:"value";s:7:"content";}i:2;a:2:{s:6:"option";s:12:"Post Excerpt";s:5:"value";s:7:"excerpt";}i:3;a:2:{s:6:"option";s:12:"Custom field";s:5:"value";s:6:"custom";}i:4;a:2:{s:6:"option";s:15:"Page Screenshot";s:5:"value";s:10:"screenshot";}i:5;a:2:{s:6:"option";s:13:"Default image";s:5:"value";s:7:"default";}i:6;a:2:{s:6:"option";s:8:"Disabled";s:5:"value";s:8:"disabled";}}s:13:"image_source1";s:8:"featured";s:13:"image_source2";s:7:"content";s:13:"image_source3";s:7:"excerpt";s:13:"image_source4";s:6:"custom";s:13:"image_source5";s:7:"default";s:13:"image_default";s:88:"http://localhost:8888/onceuponawatch/wp-content/plugins/ajax-search-lite/img/default.jpg";s:18:"image_custom_field";s:0:"";s:12:"use_timthumb";i:1;s:29:"show_frontend_search_settings";s:1:"1";s:16:"showexactmatches";s:1:"1";s:17:"showsearchinposts";s:1:"1";s:17:"showsearchinpages";s:1:"1";s:17:"showsearchintitle";s:1:"1";s:19:"showsearchincontent";s:1:"1";s:15:"showcustomtypes";s:0:"";s:20:"showsearchincomments";i:1;s:19:"showsearchinexcerpt";i:1;s:19:"showsearchinbpusers";i:0;s:20:"showsearchinbpgroups";i:0;s:20:"showsearchinbpforums";i:0;s:16:"exactmatchestext";s:19:"Mot exact seulement";s:17:"searchinpoststext";s:14:"Dans les posts";s:17:"searchinpagestext";s:14:"Dans les pages";s:17:"searchintitletext";s:13:"Dans le titre";s:19:"searchincontenttext";s:15:"Dans le contenu";s:20:"searchincommentstext";s:18:"Search in comments";s:19:"searchinexcerpttext";s:17:"Search in excerpt";s:19:"searchinbpuserstext";s:15:"Search in users";s:20:"searchinbpgroupstext";s:16:"Search in groups";s:20:"searchinbpforumstext";s:16:"Search in forums";s:22:"showsearchincategories";s:1:"1";s:17:"showuncategorised";s:1:"1";s:20:"exsearchincategories";s:0:"";s:26:"exsearchincategoriesheight";i:200;s:22:"showsearchintaxonomies";i:1;s:9:"showterms";s:0:"";s:23:"showseparatefilterboxes";i:1;s:24:"exsearchintaxonomiestext";s:9:"Filter by";s:24:"exsearchincategoriestext";s:21:"Trier par catégories";s:9:"box_width";s:4:"100%";s:10:"box_margin";s:22:"||0px||0px||0px||0px||";s:15:"resultstype_def";a:4:{i:0;a:2:{s:6:"option";s:16:"Vertical Results";s:5:"value";s:8:"vertical";}i:1;a:2:{s:6:"option";s:18:"Horizontal Results";s:5:"value";s:10:"horizontal";}i:2;a:2:{s:6:"option";s:16:"Isotopic Results";s:5:"value";s:8:"isotopic";}i:3;a:2:{s:6:"option";s:22:"Polaroid style Results";s:5:"value";s:8:"polaroid";}}s:11:"resultstype";s:8:"vertical";s:19:"resultsposition_def";a:2:{i:0;a:2:{s:6:"option";s:20:"Hover - over content";s:5:"value";s:5:"hover";}i:1;a:2:{s:6:"option";s:22:"Block - pushes content";s:5:"value";s:5:"block";}}s:15:"resultsposition";s:5:"hover";s:16:"resultsmargintop";s:4:"12px";s:17:"defaultsearchtext";s:27:"Rechercher sur le site ....";s:15:"showmoreresults";s:1:"0";s:19:"showmoreresultstext";s:18:"Plus de résultats";s:12:"showmorefont";s:151:"font-weight:normal;font-family:--g--Open Sans;color:rgba(5, 94, 148, 1);font-size:12px;line-height:15px;text-shadow:0px 0px 0px rgba(255, 255, 255, 0);";s:17:"scroll_to_results";s:1:"0";s:19:"resultareaclickable";s:1:"1";s:23:"close_on_document_click";s:1:"1";s:15:"show_close_icon";s:1:"1";s:10:"showauthor";s:1:"0";s:8:"showdate";s:1:"0";s:15:"showdescription";s:1:"1";s:17:"descriptionlength";s:3:"100";s:19:"description_context";s:1:"0";s:13:"noresultstext";s:17:"Pas de résultats";s:14:"didyoumeantext";s:19:"Vous vouliez dire :";s:12:"kw_highlight";s:1:"0";s:24:"kw_highlight_whole_words";s:1:"1";s:15:"highlight_color";s:20:"rgba(217, 49, 43, 1)";s:18:"highlight_bg_color";s:22:"rgba(238, 238, 238, 1)";s:12:"autocomplete";s:1:"0";s:14:"kw_suggestions";s:1:"0";s:9:"kw_length";s:2:"60";s:8:"kw_count";s:2:"10";s:14:"kw_google_lang";s:2:"fr";s:13:"kw_exceptions";s:0:"";s:12:"shortcode_op";s:6:"remove";s:16:"striptagsexclude";s:0:"";s:12:"runshortcode";i:1;s:14:"stripshortcode";i:0;s:19:"pageswithcategories";i:0;s:14:"titlefield_def";a:2:{i:0;a:2:{s:6:"option";s:10:"Post Title";s:5:"value";i:0;}i:1;a:2:{s:6:"option";s:12:"Post Excerpt";s:5:"value";i:1;}}s:10:"titlefield";s:1:"0";s:20:"descriptionfield_def";a:3:{i:0;a:2:{s:6:"option";s:16:"Post Description";s:5:"value";i:0;}i:1;a:2:{s:6:"option";s:12:"Post Excerpt";s:5:"value";i:1;}i:2;a:2:{s:6:"option";s:10:"Post Title";s:5:"value";i:2;}}s:16:"descriptionfield";s:1:"0";s:17:"excludecategories";s:0:"";s:12:"excludeposts";s:0:"";s:16:"exclude_term_ids";s:0:"";s:18:"wpml_compatibility";s:1:"1";s:21:"classname-customtypes";s:23:"wpdreamsCustomPostTypes";s:22:"classname-customfields";s:20:"wpdreamsCustomFields";s:10:"asl_submit";s:1:"1";s:10:"submit_asl";s:13:"Save options!";s:25:"classname-showcustomtypes";s:31:"wpdreamsCustomPostTypesEditable";s:30:"classname-exsearchincategories";s:18:"wpdreamsCategories";s:7:"topleft";s:3:"0px";s:11:"bottomright";s:3:"0px";s:8:"topright";s:3:"0px";s:10:"bottomleft";s:3:"0px";s:27:"classname-excludecategories";s:18:"wpdreamsCategories";s:10:"sett_tabid";s:3:"103";s:20:"selected-customtypes";a:6:{i:0;s:17:"product_variation";i:1;s:7:"product";i:2;s:12:"shop_webhook";i:3;s:10:"shop_order";i:4;s:17:"shop_order_refund";i:5;s:11:"shop_coupon";}s:21:"selected-customfields";N;s:24:"selected-showcustomtypes";N;s:29:"selected-exsearchincategories";N;s:26:"selected-excludecategories";N;}', 'yes'),
(1353, 'theme_mods_onceuponawatch_old', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:1:{s:8:"headmenu";i:7;}}', 'yes'),
(1683, 'wpcf7', 'a:2:{s:7:"version";s:5:"4.4.2";s:13:"bulk_validate";a:4:{s:9:"timestamp";d:1463418556;s:7:"version";s:5:"4.4.2";s:11:"count_valid";i:1;s:13:"count_invalid";i:0;}}', 'yes'),
(2126, 'category_children', 'a:0:{}', 'yes'),
(2560, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(2657, 'product_shipping_class_children', 'a:0:{}', 'yes'),
(2782, 'pa_orange_children', 'a:0:{}', 'yes'),
(2783, 'pa_rose_children', 'a:0:{}', 'yes'),
(2819, 'pa_noir_children', 'a:0:{}', 'yes'),
(2929, 'pa_couleur_children', 'a:0:{}', 'yes'),
(3912, 'catalog_options', '', 'yes'),
(3913, 'image_options', '', 'yes'),
(4315, 'product_cat_children', 'a:1:{i:10;a:2:{i:0;i:11;i:1;i:12;}}', 'yes'),
(4732, 'pa_marque_children', 'a:0:{}', 'yes'),
(5282, 'wpmembers_settings', 'a:19:{s:7:"version";s:7:"3.1.0.3";s:6:"notify";i:0;s:7:"mod_reg";i:0;s:7:"captcha";s:1:"0";s:7:"use_exp";i:0;s:9:"use_trial";i:0;s:8:"warnings";i:0;s:10:"user_pages";a:3:{s:7:"profile";s:0:"";s:8:"register";s:0:"";s:5:"login";s:0:"";}s:6:"cssurl";s:91:"http://localhost:8888/onceuponawatch/wp-content/plugins/wp-members/css/generic-no-float.css";s:5:"style";s:91:"http://localhost:8888/onceuponawatch/wp-content/plugins/wp-members/css/generic-no-float.css";s:6:"attrib";i:0;s:10:"post_types";a:0:{}s:9:"form_tags";a:1:{s:7:"default";s:20:"Registration Default";}s:5:"email";a:2:{s:4:"from";s:0:"";s:9:"from_name";s:0:"";}s:5:"block";a:2:{s:4:"post";s:1:"1";s:4:"page";s:1:"0";}s:12:"show_excerpt";a:2:{s:4:"post";i:0;s:4:"page";i:0;}s:10:"show_login";a:2:{s:4:"post";s:1:"1";s:4:"page";s:1:"1";}s:8:"show_reg";a:2:{s:4:"post";s:1:"1";s:4:"page";s:1:"1";}s:6:"autoex";a:2:{s:4:"post";a:2:{s:7:"enabled";i:0;s:6:"length";s:0:"";}s:4:"page";a:2:{s:7:"enabled";i:0;s:6:"length";s:0:"";}}}', 'yes'),
(5283, 'wpmembers_fields', 'a:16:{i:0;a:7:{i:0;i:1;i:1;s:10:"First Name";i:2;s:10:"first_name";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";}i:1;a:7:{i:0;i:2;i:1;s:9:"Last Name";i:2;s:9:"last_name";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";}i:2;a:7:{i:0;i:3;i:1;s:9:"Address 1";i:2;s:5:"addr1";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:3;a:7:{i:0;i:4;i:1;s:9:"Address 2";i:2;s:5:"addr2";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"n";i:6;s:1:"n";}i:4;a:7:{i:0;i:5;i:1;s:4:"City";i:2;s:4:"city";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:5;a:7:{i:0;i:6;i:1;s:5:"State";i:2;s:8:"thestate";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:6;a:7:{i:0;i:7;i:1;s:3:"Zip";i:2;s:3:"zip";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:7;a:7:{i:0;i:8;i:1;s:7:"Country";i:2;s:7:"country";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:8;a:7:{i:0;i:9;i:1;s:9:"Day Phone";i:2;s:6:"phone1";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:9;a:7:{i:0;i:10;i:1;s:5:"Email";i:2;s:10:"user_email";i:3;s:5:"email";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";}i:10;a:7:{i:0;i:11;i:1;s:13:"Confirm Email";i:2;s:13:"confirm_email";i:3;s:5:"email";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";}i:11;a:7:{i:0;i:12;i:1;s:7:"Website";i:2;s:8:"user_url";i:3;s:3:"url";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"y";}i:12;a:7:{i:0;i:13;i:1;s:17:"Biographical Info";i:2;s:11:"description";i:3;s:8:"textarea";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"y";}i:13;a:7:{i:0;i:14;i:1;s:8:"Password";i:2;s:8:"password";i:3;s:8:"password";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";}i:14;a:7:{i:0;i:15;i:1;s:16:"Confirm Password";i:2;s:16:"confirm_password";i:3;s:8:"password";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";}i:15;a:9:{i:0;i:16;i:1;s:3:"TOS";i:2;s:3:"tos";i:3;s:8:"checkbox";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";i:7;s:5:"agree";i:8;s:1:"n";}}', 'yes'),
(5284, 'wpmembers_tos', 'Put your TOS (Terms of Service) text here.  You can use HTML markup.', 'yes'),
(5285, 'wpmembers_dialogs', 'a:9:{i:0;s:119:"This content is restricted to site members.  If you are an existing user, please log in.  New users may register below.";i:1;s:50:"Sorry, that username is taken, please try another.";i:2;s:74:"Sorry, that email address already has an account.<br />Please try another.";i:3;s:124:"Congratulations! Your registration was successful.<br /><br />You may now log in using the password that was emailed to you.";i:4;s:29:"Your information was updated!";i:5;s:53:"Passwords did not match.<br /><br />Please try again.";i:6;s:30:"Password successfully changed!";i:7;s:65:"Either the username or email address do not exist in our records.";i:8;s:135:"Password successfully reset!<br /><br />An email containing a new password has been sent to the email address on file for your account.";}', 'yes'),
(5286, 'wpmembers_email_newreg', 'a:2:{s:4:"subj";s:37:"Your registration info for [blogname]";s:4:"body";s:268:"Thank you for registering for [blogname]\r\n\r\nYour registration information is below.\r\nYou may wish to retain a copy for your records.\r\n\r\nusername: [username]\r\npassword: [password]\r\n\r\nYou may login here:\r\n[reglink]\r\n\r\nYou may change your password here:\r\n[members-area]\r\n";}', 'no'),
(5287, 'wpmembers_email_newmod', 'a:2:{s:4:"subj";s:40:"Thank you for registering for [blogname]";s:4:"body";s:173:"Thank you for registering for [blogname]. \r\nYour registration has been received and is pending approval.\r\nYou will receive login instructions upon approval of your account\r\n";}', 'no'),
(5288, 'wpmembers_email_appmod', 'a:2:{s:4:"subj";s:50:"Your registration for [blogname] has been approved";s:4:"body";s:299:"Your registration for [blogname] has been approved.\r\n\r\nYour registration information is below.\r\nYou may wish to retain a copy for your records.\r\n\r\nusername: [username]\r\npassword: [password]\r\n\r\nYou may login and change your password here:\r\n[members-area]\r\n\r\nYou originally registered at:\r\n[reglink]\r\n";}', 'no'),
(5289, 'wpmembers_email_repass', 'a:2:{s:4:"subj";s:34:"Your password reset for [blogname]";s:4:"body";s:157:"Your password for [blogname] has been reset\r\n\r\nYour new password is included below. You may wish to retain a copy for your records.\r\n\r\npassword: [password]\r\n";}', 'no'),
(5290, 'wpmembers_email_notify', 'a:2:{s:4:"subj";s:36:"New user registration for [blogname]";s:4:"body";s:194:"The following user registered for [blogname]:\r\n\r\nusername: [username]\r\nemail: [email]\r\n\r\n[fields]\r\nThis user registered here:\r\n[reglink]\r\n\r\nuser IP: [user-ip]\r\n\r\nactivate user: [activate-user]\r\n";}', 'no'),
(5291, 'wpmembers_email_footer', '----------------------------------\r\nThis is an automated message from [blogname]\r\nPlease do not reply to this address', 'no'),
(5292, 'wpmembers_email_getuser', 'a:2:{s:4:"subj";s:23:"Username for [blogname]";s:4:"body";s:64:"Your username for [blogname] is below.\r\n\r\nusername: [username]\r\n";}', 'no'),
(5293, 'wpmembers_style', 'http://localhost:8888/onceuponawatch/wp-content/plugins/wp-members/css/generic-no-float.css', 'yes'),
(5295, 'widget_widget_wpmemwidget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(6587, 'wpseo', 'a:21:{s:14:"blocking_files";a:0:{}s:26:"ignore_blog_public_warning";b:0;s:31:"ignore_meta_description_warning";b:0;s:20:"ignore_page_comments";b:0;s:16:"ignore_permalink";b:0;s:15:"ms_defaults_set";b:0;s:23:"theme_description_found";s:0:"";s:21:"theme_has_description";b:0;s:7:"version";s:5:"3.2.5";s:11:"alexaverify";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";}', 'yes'),
(6588, 'wpseo_permalinks', 'a:9:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(6589, 'wpseo_titles', 'a:91:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:5:"noodp";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Auteur à %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:65:"Vous avez cherché %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:38:"Page non trouvée %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:19:"disable-post_format";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:14:"title-annonces";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:17:"metadesc-annonces";s:0:"";s:16:"metakey-annonces";s:0:"";s:16:"noindex-annonces";b:0;s:17:"showdate-annonces";b:0;s:20:"hideeditbox-annonces";b:0;s:13:"title-product";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:16:"metadesc-product";s:0:"";s:15:"metakey-product";s:0:"";s:15:"noindex-product";b:0;s:16:"showdate-product";b:0;s:19:"hideeditbox-product";b:0;s:24:"title-ptarchive-annonces";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:27:"metadesc-ptarchive-annonces";s:0:"";s:26:"metakey-ptarchive-annonces";s:0:"";s:26:"bctitle-ptarchive-annonces";s:0:"";s:26:"noindex-ptarchive-annonces";b:0;s:23:"title-ptarchive-product";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:26:"metadesc-ptarchive-product";s:0:"";s:25:"metakey-ptarchive-product";s:0:"";s:25:"bctitle-ptarchive-product";s:0:"";s:25:"noindex-ptarchive-product";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;s:21:"title-tax-product_cat";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-product_cat";s:0:"";s:23:"metakey-tax-product_cat";s:0:"";s:27:"hideeditbox-tax-product_cat";b:0;s:23:"noindex-tax-product_cat";b:0;s:21:"title-tax-product_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-product_tag";s:0:"";s:23:"metakey-tax-product_tag";s:0:"";s:27:"hideeditbox-tax-product_tag";b:0;s:23:"noindex-tax-product_tag";b:0;s:32:"title-tax-product_shipping_class";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:35:"metadesc-tax-product_shipping_class";s:0:"";s:34:"metakey-tax-product_shipping_class";s:0:"";s:38:"hideeditbox-tax-product_shipping_class";b:0;s:34:"noindex-tax-product_shipping_class";b:0;}', 'yes'),
(6590, 'wpseo_social', 'a:20:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"305312802b4d7959e4480523488bf5a4";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(6591, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:64:"Cet article %%POSTLINK%% est apparu en premier sur %%BLOGLINK%%.";}', 'yes'),
(6592, 'wpseo_internallinks', 'a:14:{s:20:"breadcrumbs-404crumb";s:28:"Erreur 404: Page introuvable";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:13:"Archives pour";s:18:"breadcrumbs-enable";b:1;s:16:"breadcrumbs-home";s:7:"Accueil";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:18:"Vous avez cherché";s:15:"breadcrumbs-sep";s:2:"»";s:23:"post_types-post-maintax";s:8:"category";s:26:"post_types-product-maintax";i:0;s:29:"taxonomy-product_cat-ptparent";i:0;s:29:"taxonomy-product_tag-ptparent";i:0;s:40:"taxonomy-product_shipping_class-ptparent";i:0;}', 'yes'),
(6593, 'wpseo_xml', 'a:23:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:33:"user_role-customer-not_in_sitemap";b:0;s:37:"user_role-shop_manager-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"post_types-annonces-not_in_sitemap";b:0;s:33:"post_types-product-not_in_sitemap";b:0;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;s:37:"taxonomies-product_cat-not_in_sitemap";b:0;s:37:"taxonomies-product_tag-not_in_sitemap";b:0;s:48:"taxonomies-product_shipping_class-not_in_sitemap";b:0;}', 'yes'),
(6594, 'wpseo_flush_rewrite', '1', 'yes'),
(6672, 'wpseo_sitemap_1_cache_validator', 'mLRn', 'yes'),
(6673, 'wpseo_sitemap_annonces_cache_validator', '4751Y', 'yes'),
(6743, 'wpseo_sitemap_product_cache_validator', '4qUwZ', 'yes'),
(6744, 'wpseo_sitemap_product_type_cache_validator', '4qUwI', 'yes'),
(6790, 'wpseo_sitemap_nav_menu_item_cache_validator', '44nNf', 'yes'),
(6792, 'wpseo_sitemap_nav_menu_cache_validator', '44nNi', 'yes'),
(6795, 'wpseo_sitemap_78_cache_validator', '4sYsx', 'yes'),
(7382, 'wpseo_sitemap_36_cache_validator', '44nN8', 'yes'),
(7645, 'wpseo_sitemap_page_cache_validator', '4mrt6', 'yes'),
(7716, 'wpseo_sitemap_wpcf7_contact_form_cache_validator', 'mLRn', 'yes'),
(8266, '_wp_session_b435e9367a0b3b62ff42eaad563f8f8c', 'a:0:{}', 'no'),
(8267, '_wp_session_expires_b435e9367a0b3b62ff42eaad563f8f8c', '1464194480', 'no'),
(8332, '_wp_session_expires_9d4158e02969c3f3a187a1f1443a7910', '1464195435', 'no'),
(8384, '_wp_session_eac081d53c9cc506684b1742470c39ed', 'a:0:{}', 'no'),
(8385, '_wp_session_expires_eac081d53c9cc506684b1742470c39ed', '1464196235', 'no'),
(8440, '_wp_session_f5179d7e9a064be86b79be537099c638', 'a:0:{}', 'no'),
(8441, '_wp_session_expires_f5179d7e9a064be86b79be537099c638', '1464196585', 'no'),
(8442, '_wp_session_d46875e110f689b5b0de71f39e15cdb9', 'a:0:{}', 'no'),
(8443, '_wp_session_expires_d46875e110f689b5b0de71f39e15cdb9', '1464196585', 'no'),
(8444, '_wp_session_0501690832adb5c9d37e28742794ba8a', 'a:0:{}', 'no'),
(8445, '_wp_session_expires_0501690832adb5c9d37e28742794ba8a', '1464196593', 'no'),
(8446, '_wp_session_46e271fd8bd6fc7d30d8640ad331e59f', 'a:0:{}', 'no'),
(8447, '_wp_session_expires_46e271fd8bd6fc7d30d8640ad331e59f', '1464196594', 'no'),
(8463, '_wp_session_9d4158e02969c3f3a187a1f1443a7910', 'a:0:{}', 'no') ;

#
# End of data contents of table `wp_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_postmeta`
#

DROP TABLE IF EXISTS `wp_postmeta`;


#
# Table structure of table `wp_postmeta`
#

CREATE TABLE `wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=499 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_postmeta`
#
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 8, '_edit_last', '1'),
(3, 8, '_edit_lock', '1463576137:1'),
(4, 8, '_visibility', 'visible'),
(5, 8, '_stock_status', 'instock'),
(6, 8, 'total_sales', '1238'),
(7, 8, '_downloadable', 'no'),
(8, 8, '_virtual', 'yes'),
(9, 8, '_purchase_note', ''),
(10, 8, '_featured', 'no'),
(11, 8, '_weight', ''),
(12, 8, '_length', ''),
(13, 8, '_width', ''),
(14, 8, '_height', ''),
(15, 8, '_sku', ''),
(16, 8, '_product_attributes', 'a:0:{}'),
(17, 8, '_regular_price', '200'),
(18, 8, '_sale_price', ''),
(19, 8, '_sale_price_dates_from', ''),
(20, 8, '_sale_price_dates_to', ''),
(21, 8, '_price', '200'),
(22, 8, '_sold_individually', ''),
(23, 8, '_manage_stock', 'no'),
(24, 8, '_backorders', 'no'),
(25, 8, '_stock', ''),
(26, 8, '_upsell_ids', 'a:0:{}'),
(27, 8, '_crosssell_ids', 'a:0:{}'),
(28, 8, '_product_version', '2.5.5'),
(29, 8, '_product_image_gallery', ''),
(30, 8, '_wc_rating_count', 'a:0:{}'),
(31, 8, '_wc_review_count', '0'),
(32, 8, '_wc_average_rating', '0'),
(33, 9, '_edit_last', '1'),
(34, 9, '_edit_lock', '1463582508:1'),
(35, 9, '_visibility', 'visible'),
(36, 9, '_stock_status', 'instock'),
(37, 9, 'total_sales', '0'),
(38, 9, '_downloadable', 'no'),
(39, 9, '_virtual', 'no'),
(40, 9, '_purchase_note', ''),
(41, 9, '_featured', 'no'),
(42, 9, '_weight', ''),
(43, 9, '_length', ''),
(44, 9, '_width', ''),
(45, 9, '_height', ''),
(46, 9, '_sku', ''),
(47, 9, '_product_attributes', 'a:1:{s:9:"pa_marque";a:6:{s:4:"name";s:9:"pa_marque";s:5:"value";s:0:"";s:8:"position";s:1:"1";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}}'),
(48, 9, '_regular_price', '120'),
(49, 9, '_sale_price', ''),
(50, 9, '_sale_price_dates_from', ''),
(51, 9, '_sale_price_dates_to', ''),
(52, 9, '_price', '120'),
(53, 9, '_sold_individually', ''),
(54, 9, '_manage_stock', 'no'),
(55, 9, '_backorders', 'no'),
(56, 9, '_stock', ''),
(57, 9, '_upsell_ids', 'a:0:{}'),
(58, 9, '_crosssell_ids', 'a:0:{}'),
(59, 9, '_product_version', '2.5.5'),
(60, 9, '_product_image_gallery', ''),
(61, 9, '_wc_rating_count', 'a:0:{}'),
(62, 9, '_wc_review_count', '0'),
(63, 9, '_wc_average_rating', '0'),
(64, 11, '_wp_attached_file', '2016/05/montre.png'),
(65, 11, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:507;s:6:"height";i:414;s:4:"file";s:18:"2016/05/montre.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"montre-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:18:"montre-300x245.png";s:5:"width";i:300;s:6:"height";i:245;s:9:"mime-type";s:9:"image/png";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"montre-180x180.png";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:9:"image/png";}s:12:"shop_catalog";a:4:{s:4:"file";s:18:"montre-300x300.png";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(67, 12, '_form', '<div class="row">\n    <div class="large-6 small-12 columns"><label for="your-name">Votre nom</label>[text* your-name]</div>\n    <div class="large-6 small-12 columns"><label for="your-email">Votre e-mail</label>[email* your-email]</div>\n</div>\n<div class="row">\n    <div class="small-12 columns"><label for="your-subject">Sujet</label>[text your-subject]</div>\n</div>\n<div class="row">\n    <div class="small-12 columns"><label for="your-message">Message</label>[textarea your-message]</div>\n</div>\n<div class="text-center">[submit "Send"]</div>'),
(68, 12, '_mail', 'a:8:{s:7:"subject";s:34:"Once Upon a Watch "[your-subject]"";s:6:"sender";s:38:"[your-name] <alexandre.kong@gmail.com>";s:4:"body";s:191:"From: [your-name] <[your-email]>\nSubject: [your-subject]\n\nMessage Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on Once Upon a Watch (http://localhost:8888/onceuponawatch)";s:9:"recipient";s:24:"alexandre.kong@gmail.com";s:18:"additional_headers";s:22:"Reply-To: [your-email]";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(69, 12, '_mail_2', 'a:9:{s:6:"active";b:0;s:7:"subject";s:34:"Once Upon a Watch "[your-subject]"";s:6:"sender";s:44:"Once Upon a Watch <alexandre.kong@gmail.com>";s:4:"body";s:133:"Message Body:\n[your-message]\n\n--\nThis e-mail was sent from a contact form on Once Upon a Watch (http://localhost:8888/onceuponawatch)";s:9:"recipient";s:12:"[your-email]";s:18:"additional_headers";s:34:"Reply-To: alexandre.kong@gmail.com";s:11:"attachments";s:0:"";s:8:"use_html";b:0;s:13:"exclude_blank";b:0;}'),
(70, 12, '_messages', 'a:23:{s:12:"mail_sent_ok";s:45:"Thank you for your message. It has been sent.";s:12:"mail_sent_ng";s:71:"There was an error trying to send your message. Please try again later.";s:16:"validation_error";s:61:"One or more fields have an error. Please check and try again.";s:4:"spam";s:71:"There was an error trying to send your message. Please try again later.";s:12:"accept_terms";s:69:"You must accept the terms and conditions before sending your message.";s:16:"invalid_required";s:22:"The field is required.";s:16:"invalid_too_long";s:22:"The field is too long.";s:17:"invalid_too_short";s:23:"The field is too short.";s:12:"invalid_date";s:29:"The date format is incorrect.";s:14:"date_too_early";s:44:"The date is before the earliest one allowed.";s:13:"date_too_late";s:41:"The date is after the latest one allowed.";s:13:"upload_failed";s:46:"There was an unknown error uploading the file.";s:24:"upload_file_type_invalid";s:49:"You are not allowed to upload files of this type.";s:21:"upload_file_too_large";s:20:"The file is too big.";s:23:"upload_failed_php_error";s:38:"There was an error uploading the file.";s:14:"invalid_number";s:29:"The number format is invalid.";s:16:"number_too_small";s:47:"The number is smaller than the minimum allowed.";s:16:"number_too_large";s:46:"The number is larger than the maximum allowed.";s:23:"quiz_answer_not_correct";s:36:"The answer to the quiz is incorrect.";s:17:"captcha_not_match";s:31:"Your entered code is incorrect.";s:13:"invalid_email";s:38:"The e-mail address entered is invalid.";s:11:"invalid_url";s:19:"The URL is invalid.";s:11:"invalid_tel";s:32:"The telephone number is invalid.";}'),
(71, 12, '_additional_settings', ''),
(72, 12, '_locale', 'fr_FR'),
(73, 13, '_edit_last', '1'),
(74, 13, '_edit_lock', '1463436385:1'),
(75, 14, '_wp_attached_file', '2016/05/visuel2.jpg'),
(76, 14, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:860;s:6:"height";i:802;s:4:"file";s:19:"2016/05/visuel2.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"visuel2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"visuel2-300x280.jpg";s:5:"width";i:300;s:6:"height";i:280;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"visuel2-768x716.jpg";s:5:"width";i:768;s:6:"height";i:716;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:19:"visuel2-640x597.jpg";s:5:"width";i:640;s:6:"height";i:597;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"visuel2-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:19:"visuel2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:19:"visuel2-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(77, 13, '_thumbnail_id', '14'),
(80, 16, '_edit_last', '1'),
(81, 16, '_edit_lock', '1463436423:1'),
(82, 17, '_wp_attached_file', '2016/05/testwatch.jpg'),
(83, 17, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:972;s:6:"height";i:426;s:4:"file";s:21:"2016/05/testwatch.jpg";s:5:"sizes";a:7:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"testwatch-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"testwatch-300x131.jpg";s:5:"width";i:300;s:6:"height";i:131;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"testwatch-768x337.jpg";s:5:"width";i:768;s:6:"height";i:337;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:21:"testwatch-640x280.jpg";s:5:"width";i:640;s:6:"height";i:280;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"testwatch-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"testwatch-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:21:"testwatch-600x426.jpg";s:5:"width";i:600;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(84, 16, '_thumbnail_id', '17'),
(87, 1, '_wp_trash_meta_status', 'publish'),
(88, 1, '_wp_trash_meta_time', '1463436571'),
(89, 1, '_wp_desired_post_slug', 'bonjour-tout-le-monde'),
(90, 1, '_wp_trash_meta_comments_status', 'a:1:{i:1;s:1:"1";}'),
(91, 20, '_edit_last', '1'),
(92, 20, '_edit_lock', '1463573888:1'),
(93, 21, '_wp_attached_file', '2016/05/watch-in.jpg'),
(94, 21, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:1080;s:4:"file";s:20:"2016/05/watch-in.jpg";s:5:"sizes";a:10:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"watch-in-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"watch-in-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"watch-in-768x432.jpg";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"watch-in-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:20:"watch-in-640x360.jpg";s:5:"width";i:640;s:6:"height";i:360;s:9:"mime-type";s:10:"image/jpeg";}s:9:"fp-medium";a:4:{s:4:"file";s:21:"watch-in-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-large";a:4:{s:4:"file";s:21:"watch-in-1200x675.jpg";s:5:"width";i:1200;s:6:"height";i:675;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:20:"watch-in-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:20:"watch-in-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:20:"watch-in-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(95, 20, '_thumbnail_id', '21'),
(98, 23, '_edit_last', '1'),
(99, 23, '_edit_lock', '1463670562:1'),
(100, 23, '_visibility', 'visible'),
(101, 23, '_stock_status', 'instock'),
(102, 23, 'total_sales', '0'),
(103, 23, '_downloadable', 'no'),
(104, 23, '_virtual', 'no'),
(105, 23, '_purchase_note', ''),
(106, 23, '_featured', 'no'),
(107, 23, '_weight', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(108, 23, '_length', ''),
(109, 23, '_width', ''),
(110, 23, '_height', ''),
(111, 23, '_sku', ''),
(112, 23, '_product_attributes', 'a:2:{s:10:"pa_couleur";a:6:{s:4:"name";s:10:"pa_couleur";s:5:"value";s:0:"";s:8:"position";s:1:"0";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:9:"pa_marque";a:6:{s:4:"name";s:9:"pa_marque";s:5:"value";s:0:"";s:8:"position";s:1:"1";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}}'),
(113, 23, '_regular_price', '11'),
(114, 23, '_sale_price', ''),
(115, 23, '_sale_price_dates_from', ''),
(116, 23, '_sale_price_dates_to', ''),
(117, 23, '_price', '11'),
(118, 23, '_sold_individually', ''),
(119, 23, '_manage_stock', 'no'),
(120, 23, '_backorders', 'no'),
(121, 23, '_stock', ''),
(122, 23, '_upsell_ids', 'a:0:{}'),
(123, 23, '_crosssell_ids', 'a:0:{}'),
(124, 23, '_product_version', '2.5.5'),
(125, 23, '_product_image_gallery', ''),
(126, 24, '_edit_last', '1'),
(127, 24, '_edit_lock', '1463443598:1'),
(128, 25, '_wp_attached_file', '2016/05/watch-in-1.jpg'),
(129, 25, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:1080;s:4:"file";s:22:"2016/05/watch-in-1.jpg";s:5:"sizes";a:10:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"watch-in-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"watch-in-1-300x169.jpg";s:5:"width";i:300;s:6:"height";i:169;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:22:"watch-in-1-768x432.jpg";s:5:"width";i:768;s:6:"height";i:432;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:23:"watch-in-1-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:22:"watch-in-1-640x360.jpg";s:5:"width";i:640;s:6:"height";i:360;s:9:"mime-type";s:10:"image/jpeg";}s:9:"fp-medium";a:4:{s:4:"file";s:23:"watch-in-1-1024x576.jpg";s:5:"width";i:1024;s:6:"height";i:576;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-large";a:4:{s:4:"file";s:23:"watch-in-1-1200x675.jpg";s:5:"width";i:1200;s:6:"height";i:675;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:22:"watch-in-1-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:22:"watch-in-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:22:"watch-in-1-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(130, 24, '_thumbnail_id', '25'),
(131, 29, '_edit_last', '1'),
(132, 29, '_edit_lock', '1463440186:1'),
(133, 30, '_wp_attached_file', '2016/05/header.jpg'),
(134, 30, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:1278;s:4:"file";s:18:"2016/05/header.jpg";s:5:"sizes";a:10:{s:9:"thumbnail";a:4:{s:4:"file";s:18:"header-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:18:"header-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:18:"header-768x511.jpg";s:5:"width";i:768;s:6:"height";i:511;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:19:"header-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:18:"header-640x426.jpg";s:5:"width";i:640;s:6:"height";i:426;s:9:"mime-type";s:10:"image/jpeg";}s:9:"fp-medium";a:4:{s:4:"file";s:19:"header-1024x682.jpg";s:5:"width";i:1024;s:6:"height";i:682;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-large";a:4:{s:4:"file";s:19:"header-1200x799.jpg";s:5:"width";i:1200;s:6:"height";i:799;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:18:"header-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:18:"header-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:18:"header-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:22:"Fabienne Van Pée 2015";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(135, 29, '_thumbnail_id', '30'),
(136, 32, '_edit_last', '1'),
(137, 32, '_edit_lock', '1463443879:1'),
(138, 33, '_wp_attached_file', '2016/05/hands.jpg'),
(139, 33, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1600;s:6:"height";i:1000;s:4:"file";s:17:"2016/05/hands.jpg";s:5:"sizes";a:10:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"hands-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:17:"hands-300x188.jpg";s:5:"width";i:300;s:6:"height";i:188;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:17:"hands-768x480.jpg";s:5:"width";i:768;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:18:"hands-1024x640.jpg";s:5:"width";i:1024;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:17:"hands-640x400.jpg";s:5:"width";i:640;s:6:"height";i:400;s:9:"mime-type";s:10:"image/jpeg";}s:9:"fp-medium";a:4:{s:4:"file";s:18:"hands-1024x640.jpg";s:5:"width";i:1024;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-large";a:4:{s:4:"file";s:18:"hands-1200x750.jpg";s:5:"width";i:1200;s:6:"height";i:750;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:17:"hands-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:17:"hands-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:17:"hands-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(140, 32, '_thumbnail_id', '33'),
(159, 37, '_menu_item_type', 'custom'),
(160, 37, '_menu_item_menu_item_parent', '0'),
(161, 37, '_menu_item_object_id', '37'),
(162, 37, '_menu_item_object', 'custom'),
(163, 37, '_menu_item_target', ''),
(164, 37, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(165, 37, '_menu_item_xfn', ''),
(166, 37, '_menu_item_url', 'http://localhost:8888/onceuponawatch/'),
(168, 38, '_edit_last', '1'),
(169, 38, '_edit_lock', '1463581932:1'),
(171, 38, '_visibility', 'visible'),
(172, 38, '_stock_status', 'instock'),
(173, 38, 'total_sales', '3876'),
(174, 38, '_downloadable', 'no'),
(175, 38, '_virtual', 'no'),
(176, 38, '_purchase_note', ''),
(177, 38, '_featured', 'no'),
(178, 38, '_weight', ''),
(179, 38, '_length', ''),
(180, 38, '_width', ''),
(181, 38, '_height', ''),
(182, 38, '_sku', ''),
(183, 38, '_product_attributes', 'a:2:{s:9:"pa_marque";a:6:{s:4:"name";s:9:"pa_marque";s:5:"value";s:0:"";s:8:"position";s:1:"0";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}s:10:"pa_couleur";a:6:{s:4:"name";s:10:"pa_couleur";s:5:"value";s:0:"";s:8:"position";s:1:"1";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}}'),
(184, 38, '_regular_price', '100'),
(185, 38, '_sale_price', ''),
(186, 38, '_sale_price_dates_from', ''),
(187, 38, '_sale_price_dates_to', ''),
(188, 38, '_price', '100'),
(189, 38, '_sold_individually', ''),
(190, 38, '_manage_stock', 'no'),
(191, 38, '_backorders', 'no'),
(192, 38, '_stock', ''),
(193, 38, '_upsell_ids', 'a:0:{}'),
(194, 38, '_crosssell_ids', 'a:0:{}'),
(195, 38, '_product_version', '2.5.5'),
(196, 38, '_product_image_gallery', '33,30,25'),
(209, 23, '_wc_rating_count', 'a:0:{}'),
(210, 23, '_wc_average_rating', '0'),
(211, 23, '_wc_review_count', '0'),
(243, 51, '_wp_attached_file', '2016/05/montre1.jpg'),
(244, 51, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1164;s:4:"file";s:19:"2016/05/montre1.jpg";s:5:"sizes";a:10:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"montre1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"montre1-300x175.jpg";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"montre1-768x447.jpg";s:5:"width";i:768;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"montre1-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:19:"montre1-640x372.jpg";s:5:"width";i:640;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:9:"fp-medium";a:4:{s:4:"file";s:20:"montre1-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-large";a:4:{s:4:"file";s:20:"montre1-1200x698.jpg";s:5:"width";i:1200;s:6:"height";i:698;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"montre1-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:19:"montre1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:19:"montre1-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(245, 52, '_wp_attached_file', '2016/05/montre2.jpg'),
(246, 52, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1164;s:4:"file";s:19:"2016/05/montre2.jpg";s:5:"sizes";a:10:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"montre2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"montre2-300x175.jpg";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"montre2-768x447.jpg";s:5:"width";i:768;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"montre2-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:19:"montre2-640x372.jpg";s:5:"width";i:640;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:9:"fp-medium";a:4:{s:4:"file";s:20:"montre2-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-large";a:4:{s:4:"file";s:20:"montre2-1200x698.jpg";s:5:"width";i:1200;s:6:"height";i:698;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"montre2-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:19:"montre2-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:19:"montre2-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(247, 53, '_wp_attached_file', '2016/05/montre3.jpg'),
(248, 53, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1164;s:4:"file";s:19:"2016/05/montre3.jpg";s:5:"sizes";a:10:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"montre3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"montre3-300x175.jpg";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"montre3-768x447.jpg";s:5:"width";i:768;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"montre3-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:19:"montre3-640x372.jpg";s:5:"width";i:640;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:9:"fp-medium";a:4:{s:4:"file";s:20:"montre3-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-large";a:4:{s:4:"file";s:20:"montre3-1200x698.jpg";s:5:"width";i:1200;s:6:"height";i:698;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"montre3-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:19:"montre3-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:19:"montre3-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(249, 54, '_wp_attached_file', '2016/05/montre4.jpg'),
(250, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1164;s:4:"file";s:19:"2016/05/montre4.jpg";s:5:"sizes";a:10:{s:9:"thumbnail";a:4:{s:4:"file";s:19:"montre4-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:19:"montre4-300x175.jpg";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:19:"montre4-768x447.jpg";s:5:"width";i:768;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:20:"montre4-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:19:"montre4-640x372.jpg";s:5:"width";i:640;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:9:"fp-medium";a:4:{s:4:"file";s:20:"montre4-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-large";a:4:{s:4:"file";s:20:"montre4-1200x698.jpg";s:5:"width";i:1200;s:6:"height";i:698;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:19:"montre4-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:19:"montre4-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:19:"montre4-600x600.jpg";s:5:"width";i:600;s:6:"height";i:600;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(251, 38, '_thumbnail_id', '51'),
(253, 9, '_thumbnail_id', '52'),
(254, 8, '_thumbnail_id', '54'),
(255, 55, '_edit_last', '1'),
(256, 55, '_edit_lock', '1463587184:1'),
(257, 55, '_thumbnail_id', '52'),
(258, 55, '_visibility', 'visible'),
(259, 55, '_stock_status', 'instock'),
(260, 55, 'total_sales', '0'),
(261, 55, '_downloadable', 'no'),
(262, 55, '_virtual', 'no'),
(263, 55, '_purchase_note', ''),
(264, 55, '_featured', 'no'),
(265, 55, '_weight', ''),
(266, 55, '_length', ''),
(267, 55, '_width', ''),
(268, 55, '_height', ''),
(269, 55, '_sku', ''),
(270, 55, '_product_attributes', 'a:0:{}'),
(271, 55, '_regular_price', '123') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(272, 55, '_sale_price', ''),
(273, 55, '_sale_price_dates_from', ''),
(274, 55, '_sale_price_dates_to', ''),
(275, 55, '_price', '123'),
(276, 55, '_sold_individually', ''),
(277, 55, '_manage_stock', 'no'),
(278, 55, '_backorders', 'no'),
(279, 55, '_stock', ''),
(280, 55, '_upsell_ids', 'a:0:{}'),
(281, 55, '_crosssell_ids', 'a:0:{}'),
(282, 55, '_product_version', '2.5.5'),
(283, 55, '_product_image_gallery', ''),
(286, 56, '_edit_last', '1'),
(287, 56, '_edit_lock', '1464089000:1'),
(288, 56, '_thumbnail_id', '51'),
(289, 56, '_visibility', 'visible'),
(290, 56, '_stock_status', 'instock'),
(291, 56, 'total_sales', '0'),
(292, 56, '_downloadable', 'no'),
(293, 56, '_virtual', 'no'),
(294, 56, '_purchase_note', ''),
(295, 56, '_featured', 'no'),
(296, 56, '_weight', ''),
(297, 56, '_length', ''),
(298, 56, '_width', ''),
(299, 56, '_height', ''),
(300, 56, '_sku', ''),
(301, 56, '_product_attributes', 'a:0:{}'),
(302, 56, '_regular_price', '123'),
(303, 56, '_sale_price', ''),
(304, 56, '_sale_price_dates_from', ''),
(305, 56, '_sale_price_dates_to', ''),
(306, 56, '_price', '123'),
(307, 56, '_sold_individually', ''),
(308, 56, '_manage_stock', 'no'),
(309, 56, '_backorders', 'no'),
(310, 56, '_stock', ''),
(311, 56, '_upsell_ids', 'a:0:{}'),
(312, 56, '_crosssell_ids', 'a:0:{}'),
(313, 56, '_product_version', '2.5.5'),
(314, 56, '_product_image_gallery', ''),
(315, 56, '_wc_rating_count', 'a:0:{}'),
(316, 56, '_wc_average_rating', '0'),
(317, 56, '_wc_review_count', '0'),
(318, 57, '_wp_attached_file', '2016/05/Mode-Bracelets-montre-femme-chaude-montres-de-haute-qualité-femmes-en-cuir-véritable-Vintage-montre-bracelet.jpg'),
(319, 57, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:667;s:6:"height";i:415;s:4:"file";s:124:"2016/05/Mode-Bracelets-montre-femme-chaude-montres-de-haute-qualité-femmes-en-cuir-véritable-Vintage-montre-bracelet.jpg";s:5:"sizes";a:6:{s:9:"thumbnail";a:4:{s:4:"file";s:124:"Mode-Bracelets-montre-femme-chaude-montres-de-haute-qualité-femmes-en-cuir-véritable-Vintage-montre-bracelet-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:124:"Mode-Bracelets-montre-femme-chaude-montres-de-haute-qualité-femmes-en-cuir-véritable-Vintage-montre-bracelet-300x187.jpg";s:5:"width";i:300;s:6:"height";i:187;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:124:"Mode-Bracelets-montre-femme-chaude-montres-de-haute-qualité-femmes-en-cuir-véritable-Vintage-montre-bracelet-640x398.jpg";s:5:"width";i:640;s:6:"height";i:398;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:124:"Mode-Bracelets-montre-femme-chaude-montres-de-haute-qualité-femmes-en-cuir-véritable-Vintage-montre-bracelet-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:124:"Mode-Bracelets-montre-femme-chaude-montres-de-haute-qualité-femmes-en-cuir-véritable-Vintage-montre-bracelet-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}s:11:"shop_single";a:4:{s:4:"file";s:124:"Mode-Bracelets-montre-femme-chaude-montres-de-haute-qualité-femmes-en-cuir-véritable-Vintage-montre-bracelet-600x415.jpg";s:5:"width";i:600;s:6:"height";i:415;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(323, 38, '_wc_rating_count', 'a:2:{i:2;s:1:"1";i:4;s:1:"1";}'),
(324, 38, '_wc_review_count', '2'),
(325, 38, '_wc_average_rating', '3.00'),
(326, 58, '_edit_last', '1'),
(327, 58, '_edit_lock', '1463671964:1'),
(328, 59, '_wp_attached_file', '2016/05/montre4-1.jpg'),
(329, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1164;s:4:"file";s:21:"2016/05/montre4-1.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"montre4-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"montre4-1-300x175.jpg";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"montre4-1-768x447.jpg";s:5:"width";i:768;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"montre4-1-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:21:"montre4-1-640x372.jpg";s:5:"width";i:640;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:9:"fp-medium";a:4:{s:4:"file";s:22:"montre4-1-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-large";a:4:{s:4:"file";s:22:"montre4-1-1200x698.jpg";s:5:"width";i:1200;s:6:"height";i:698;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"montre4-1-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"montre4-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(330, 58, '_thumbnail_id', '59'),
(331, 58, '_visibility', 'visible'),
(332, 58, '_stock_status', 'instock'),
(333, 58, 'total_sales', '0'),
(334, 58, '_downloadable', 'no'),
(335, 58, '_virtual', 'no'),
(336, 58, '_purchase_note', ''),
(337, 58, '_featured', 'no'),
(338, 58, '_weight', ''),
(339, 58, '_length', ''),
(340, 58, '_width', ''),
(341, 58, '_height', ''),
(342, 58, '_sku', ''),
(343, 58, '_product_attributes', 'a:1:{s:10:"pa_couleur";a:6:{s:4:"name";s:10:"pa_couleur";s:5:"value";s:0:"";s:8:"position";s:1:"0";s:10:"is_visible";i:1;s:12:"is_variation";i:0;s:11:"is_taxonomy";i:1;}}'),
(344, 58, '_regular_price', '12387'),
(345, 58, '_sale_price', ''),
(346, 58, '_sale_price_dates_from', ''),
(347, 58, '_sale_price_dates_to', ''),
(348, 58, '_price', '12387'),
(349, 58, '_sold_individually', ''),
(350, 58, '_manage_stock', 'no'),
(351, 58, '_backorders', 'no'),
(352, 58, '_stock', ''),
(353, 58, '_upsell_ids', 'a:0:{}'),
(354, 58, '_crosssell_ids', 'a:0:{}'),
(355, 58, '_product_version', '2.5.5'),
(356, 58, '_product_image_gallery', '14,30,33'),
(364, 60, '_wp_attached_file', '2016/05/montre3-1.jpg'),
(365, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1164;s:4:"file";s:21:"2016/05/montre3-1.jpg";s:5:"sizes";a:8:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"montre3-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"montre3-1-300x175.jpg";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"montre3-1-768x447.jpg";s:5:"width";i:768;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"montre3-1-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:21:"montre3-1-640x372.jpg";s:5:"width";i:640;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:9:"fp-medium";a:4:{s:4:"file";s:22:"montre3-1-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-large";a:4:{s:4:"file";s:22:"montre3-1-1200x698.jpg";s:5:"width";i:1200;s:6:"height";i:698;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"montre3-1-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(367, 23, '_thumbnail_id', '53'),
(368, 61, '_menu_item_type', 'custom'),
(369, 61, '_menu_item_menu_item_parent', '0'),
(370, 61, '_menu_item_object_id', '61'),
(371, 61, '_menu_item_object', 'custom'),
(372, 61, '_menu_item_target', ''),
(373, 61, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(374, 61, '_menu_item_xfn', ''),
(375, 61, '_menu_item_url', 'http://localhost:8888/onceuponawatch/categorie-produit/montres/'),
(377, 62, '_menu_item_type', 'custom'),
(378, 62, '_menu_item_menu_item_parent', '0'),
(379, 62, '_menu_item_object_id', '62'),
(380, 62, '_menu_item_object', 'custom'),
(381, 62, '_menu_item_target', ''),
(382, 62, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(383, 62, '_menu_item_xfn', ''),
(384, 62, '_menu_item_url', 'http://localhost:8888/onceuponawatch/categorie-produit/bracelets/'),
(386, 63, '_order_key', 'wc_order_573de427b9ec0') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(387, 63, '_order_currency', 'EUR'),
(388, 63, '_prices_include_tax', 'no'),
(389, 63, '_customer_ip_address', '::1'),
(390, 63, '_customer_user_agent', 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36'),
(391, 63, '_customer_user', '1'),
(392, 63, '_created_via', 'checkout'),
(393, 63, '_order_version', '2.5.5'),
(394, 63, '_billing_first_name', 'Alexandre'),
(395, 63, '_billing_last_name', 'Kong'),
(396, 63, '_billing_company', 'Webdesigner'),
(397, 63, '_billing_email', 'alexandre.kong@gmail.com'),
(398, 63, '_billing_phone', '0666534526'),
(399, 63, '_billing_country', 'FR'),
(400, 63, '_billing_address_1', '14 rue de la Hautemontée'),
(401, 63, '_billing_address_2', ''),
(402, 63, '_billing_city', 'Strasbourg'),
(403, 63, '_billing_state', ''),
(404, 63, '_billing_postcode', '67000'),
(405, 63, '_shipping_first_name', 'Alexandre'),
(406, 63, '_shipping_last_name', 'Kong'),
(407, 63, '_shipping_company', 'Webdesigner'),
(408, 63, '_shipping_country', 'FR'),
(409, 63, '_shipping_address_1', '14 rue de la Hautemontée'),
(410, 63, '_shipping_address_2', ''),
(411, 63, '_shipping_city', 'Strasbourg'),
(412, 63, '_shipping_state', ''),
(413, 63, '_shipping_postcode', '67000'),
(414, 63, '_payment_method', 'paypal'),
(415, 63, '_payment_method_title', 'PayPal'),
(416, 63, '_order_shipping', ''),
(417, 63, '_cart_discount', '0'),
(418, 63, '_cart_discount_tax', '0'),
(419, 63, '_order_tax', '0'),
(420, 63, '_order_shipping_tax', '0'),
(421, 63, '_order_total', '0.00'),
(422, 65, '_wp_attached_file', '2016/05/montre1-1.jpg'),
(423, 65, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1164;s:4:"file";s:21:"2016/05/montre1-1.jpg";s:5:"sizes";a:9:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"montre1-1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"montre1-1-300x175.jpg";s:5:"width";i:300;s:6:"height";i:175;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:21:"montre1-1-768x447.jpg";s:5:"width";i:768;s:6:"height";i:447;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:22:"montre1-1-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-small";a:4:{s:4:"file";s:21:"montre1-1-640x372.jpg";s:5:"width";i:640;s:6:"height";i:372;s:9:"mime-type";s:10:"image/jpeg";}s:9:"fp-medium";a:4:{s:4:"file";s:22:"montre1-1-1024x596.jpg";s:5:"width";i:1024;s:6:"height";i:596;s:9:"mime-type";s:10:"image/jpeg";}s:8:"fp-large";a:4:{s:4:"file";s:22:"montre1-1-1200x698.jpg";s:5:"width";i:1200;s:6:"height";i:698;s:9:"mime-type";s:10:"image/jpeg";}s:14:"shop_thumbnail";a:4:{s:4:"file";s:21:"montre1-1-180x180.jpg";s:5:"width";i:180;s:6:"height";i:180;s:9:"mime-type";s:10:"image/jpeg";}s:12:"shop_catalog";a:4:{s:4:"file";s:21:"montre1-1-300x300.jpg";s:5:"width";i:300;s:6:"height";i:300;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"1";s:8:"keywords";a:0:{}}}'),
(424, 64, '_thumbnail_id', '65'),
(425, 64, '_edit_last', '1'),
(426, 64, '_edit_lock', '1463674719:1'),
(427, 64, '_visibility', 'visible'),
(428, 64, '_stock_status', 'instock'),
(429, 64, 'total_sales', '1'),
(430, 64, '_downloadable', 'no'),
(431, 64, '_virtual', 'yes'),
(432, 64, '_purchase_note', ''),
(433, 64, '_featured', 'no'),
(434, 64, '_weight', ''),
(435, 64, '_length', ''),
(436, 64, '_width', ''),
(437, 64, '_height', ''),
(438, 64, '_sku', ''),
(439, 64, '_product_attributes', 'a:0:{}'),
(440, 64, '_regular_price', '0'),
(441, 64, '_sale_price', ''),
(442, 64, '_sale_price_dates_from', ''),
(443, 64, '_sale_price_dates_to', ''),
(444, 64, '_price', '0'),
(445, 64, '_sold_individually', ''),
(446, 64, '_manage_stock', 'no'),
(447, 64, '_backorders', 'no'),
(448, 64, '_stock', ''),
(449, 64, '_upsell_ids', 'a:0:{}'),
(450, 64, '_crosssell_ids', 'a:0:{}'),
(451, 64, '_product_version', '2.5.5'),
(452, 64, '_product_image_gallery', ''),
(453, 64, '_wc_rating_count', 'a:0:{}'),
(454, 64, '_wc_average_rating', '0'),
(455, 64, '_wc_review_count', '0'),
(456, 63, '_download_permissions_granted', '1'),
(457, 63, '_recorded_sales', 'yes'),
(458, 63, '_paid_date', '2016-05-19 18:08:36'),
(459, 63, '_order_stock_reduced', '1'),
(461, 55, '_wc_rating_count', 'a:1:{i:2;s:1:"1";}'),
(462, 55, '_wc_review_count', '1'),
(463, 55, '_wc_average_rating', '2.00'),
(464, 66, '_edit_last', '1'),
(465, 66, '_edit_lock', '1464181418:1'),
(466, 66, '_wp_page_template', 'page-templates/contactz.php'),
(467, 68, '_menu_item_type', 'post_type'),
(468, 68, '_menu_item_menu_item_parent', '0'),
(469, 68, '_menu_item_object_id', '66'),
(470, 68, '_menu_item_object', 'page'),
(471, 68, '_menu_item_target', ''),
(472, 68, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(473, 68, '_menu_item_xfn', ''),
(474, 68, '_menu_item_url', ''),
(476, 70, '_edit_last', '1'),
(477, 70, '_wp_page_template', 'page-templates/inscription.php'),
(478, 70, '_edit_lock', '1463953658:1'),
(479, 74, '_edit_last', '1'),
(480, 74, '_edit_lock', '1463955500:1'),
(481, 75, '_edit_last', '1'),
(482, 75, '_wp_page_template', 'page-templates/news.php'),
(483, 75, '_edit_lock', '1464171325:1'),
(484, 77, '_menu_item_type', 'post_type'),
(485, 77, '_menu_item_menu_item_parent', '0'),
(486, 77, '_menu_item_object_id', '75'),
(487, 77, '_menu_item_object', 'page'),
(488, 77, '_menu_item_target', '') ;
INSERT INTO `wp_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(489, 77, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(490, 77, '_menu_item_xfn', ''),
(491, 77, '_menu_item_url', ''),
(493, 58, '_wc_rating_count', 'a:1:{i:4;s:1:"2";}'),
(494, 58, '_wc_review_count', '2'),
(495, 58, '_wc_average_rating', '4.00'),
(496, 8, '_wp_trash_meta_status', 'publish'),
(497, 8, '_wp_trash_meta_time', '1464095418'),
(498, 8, '_wp_desired_post_slug', 'cours') ;

#
# End of data contents of table `wp_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_posts`
#

DROP TABLE IF EXISTS `wp_posts`;


#
# Table structure of table `wp_posts`
#

CREATE TABLE `wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_posts`
#
INSERT INTO `wp_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-05-11 01:46:42', '2016-05-10 23:46:42', 'Bienvenue dans WordPress. Ceci est votre premier article. Modifiez-le ou supprimez-le, puis lancez-vous&nbsp;!', 'Bonjour tout le monde&nbsp;!', '', 'trash', 'open', 'open', '', 'bonjour-tout-le-monde__trashed', '', '', '2016-05-17 00:09:31', '2016-05-16 22:09:31', '', 0, 'http://localhost:8888/onceuponawatch/?p=1', 0, 'post', '', 1),
(2, 1, '2016-05-11 01:46:42', '2016-05-10 23:46:42', 'Voici un exemple de page. Elle est différente d\'un article de blog, en cela qu\'elle restera à la même place, et s\'affichera dans le menu de navigation de votre site (en fonction de votre thème). La plupart des gens commencent par écrire une page « À Propos » qui les présente aux visiteurs potentiels du site. Vous pourriez y écrire quelque chose de ce tenant :\n\n<blockquote>Bonjour ! Je suis un mécanicien qui aspire à devenir un acteur, et voici mon blog. J\'habite à Bordeaux, j\'ai un super chien baptisé Russell, et j\'aime la vodka-ananas (ainsi que regarder la pluie tomber).</blockquote>\n\n...ou bien quelque chose comme ça :\n\n<blockquote>La société 123 Machin Truc a été créée en 1971, et n\'a cessé de proposer au public des machins-trucs de qualité depuis lors. Située à Saint-Remy-en-Bouzemont-Saint-Genest-et-Isson, 123 Machin Truc emploie 2 000 personnes, et fabrique toutes sortes de bidules super pour la communauté bouzemontoise.</blockquote>\n\nÉtant donné que vous êtes un nouvel utilisateur de WordPress, vous devriez vous rendre sur votre <a href="http://localhost:8888/onceuponawatch/wp-admin/">tableau de bord</a> pour effacer la présente page, et créer de nouvelles pages avec votre propre contenu. Amusez-vous bien !', 'Page d&rsquo;exemple', '', 'publish', 'closed', 'open', '', 'page-d-exemple', '', '', '2016-05-11 01:46:42', '2016-05-10 23:46:42', '', 0, 'http://localhost:8888/onceuponawatch/?page_id=2', 0, 'page', '', 0),
(4, 1, '2016-05-12 13:54:45', '2016-05-12 11:54:45', '', 'Boutique', '', 'publish', 'closed', 'closed', '', 'boutique', '', '', '2016-05-12 13:54:45', '2016-05-12 11:54:45', '', 0, 'http://localhost:8888/onceuponawatch/boutique/', 0, 'page', '', 0),
(5, 1, '2016-05-12 13:54:45', '2016-05-12 11:54:45', '[woocommerce_cart]', 'Panier', '', 'publish', 'closed', 'closed', '', 'panier', '', '', '2016-05-12 13:54:45', '2016-05-12 11:54:45', '', 0, 'http://localhost:8888/onceuponawatch/panier/', 0, 'page', '', 0),
(6, 1, '2016-05-12 13:54:45', '2016-05-12 11:54:45', '[woocommerce_checkout]', 'Commande', '', 'publish', 'closed', 'closed', '', 'commande', '', '', '2016-05-12 13:54:45', '2016-05-12 11:54:45', '', 0, 'http://localhost:8888/onceuponawatch/commande/', 0, 'page', '', 0),
(7, 1, '2016-05-12 13:54:45', '2016-05-12 11:54:45', '[woocommerce_my_account]', 'Mon Compte', '', 'publish', 'closed', 'closed', '', 'mon-compte', '', '', '2016-05-12 13:54:45', '2016-05-12 11:54:45', '', 0, 'http://localhost:8888/onceuponawatch/mon-compte/', 0, 'page', '', 0),
(8, 1, '2016-05-12 13:55:31', '2016-05-12 11:55:31', 'Le cours se passe vendredi', 'Cours', '', 'trash', 'open', 'closed', '', 'cours__trashed', '', '', '2016-05-24 15:10:18', '2016-05-24 13:10:18', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=product&#038;p=8', 0, 'product', '', 0),
(9, 1, '2016-05-15 18:15:36', '2016-05-15 16:15:36', 'Je suis un montre', 'Montre vintage rolex', '', 'publish', 'open', 'closed', '', 'montre-vintage', '', '', '2016-05-18 16:34:52', '2016-05-18 14:34:52', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=product&#038;p=9', 0, 'product', '', 0),
(11, 1, '2016-05-15 18:18:40', '2016-05-15 16:18:40', '', 'montre', '', 'inherit', 'open', 'closed', '', 'montre', '', '', '2016-05-15 18:18:40', '2016-05-15 16:18:40', '', 9, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/montre.png', 0, 'attachment', 'image/png', 0),
(12, 1, '2016-05-16 17:09:16', '2016-05-16 15:09:16', '<div class="row">\r\n    <div class="large-6 small-12 columns"><label for="your-name">Votre nom</label>[text* your-name]</div>\r\n    <div class="large-6 small-12 columns"><label for="your-email">Votre e-mail</label>[email* your-email]</div>\r\n</div>\r\n<div class="row">\r\n    <div class="small-12 columns"><label for="your-subject">Sujet</label>[text your-subject]</div>\r\n</div>\r\n<div class="row">\r\n    <div class="small-12 columns"><label for="your-message">Message</label>[textarea your-message]</div>\r\n</div>\r\n<div class="text-center">[submit "Send"]</div>\nOnce Upon a Watch "[your-subject]"\n[your-name] <alexandre.kong@gmail.com>\nFrom: [your-name] <[your-email]>\r\nSubject: [your-subject]\r\n\r\nMessage Body:\r\n[your-message]\r\n\r\n--\r\nThis e-mail was sent from a contact form on Once Upon a Watch (http://localhost:8888/onceuponawatch)\nalexandre.kong@gmail.com\nReply-To: [your-email]\n\n\n\n\nOnce Upon a Watch "[your-subject]"\nOnce Upon a Watch <alexandre.kong@gmail.com>\nMessage Body:\r\n[your-message]\r\n\r\n--\r\nThis e-mail was sent from a contact form on Once Upon a Watch (http://localhost:8888/onceuponawatch)\n[your-email]\nReply-To: alexandre.kong@gmail.com\n\n\n\nThank you for your message. It has been sent.\nThere was an error trying to send your message. Please try again later.\nOne or more fields have an error. Please check and try again.\nThere was an error trying to send your message. Please try again later.\nYou must accept the terms and conditions before sending your message.\nThe field is required.\nThe field is too long.\nThe field is too short.\nThe date format is incorrect.\nThe date is before the earliest one allowed.\nThe date is after the latest one allowed.\nThere was an unknown error uploading the file.\nYou are not allowed to upload files of this type.\nThe file is too big.\nThere was an error uploading the file.\nThe number format is invalid.\nThe number is smaller than the minimum allowed.\nThe number is larger than the maximum allowed.\nThe answer to the quiz is incorrect.\nYour entered code is incorrect.\nThe e-mail address entered is invalid.\nThe URL is invalid.\nThe telephone number is invalid.', 'Contact form 1', '', 'publish', 'closed', 'closed', '', 'contact-form-1', '', '', '2016-05-25 15:43:29', '2016-05-25 13:43:29', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=wpcf7_contact_form&#038;p=12', 0, 'wpcf7_contact_form', '', 0),
(13, 1, '2016-05-17 00:08:19', '2016-05-16 22:08:19', 'Le <strong>Lorem Ipsum</strong> est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre cinq siècles, mais s\'est aussi adapté à la bureautique informatique, sans que son contenu n\'en soit modifié. Il a été popularisé dans les années 1960 grâce à la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus récemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.', 'Comment avoir une nouvelle montre ?', '', 'publish', 'open', 'open', '', 'comment-avoir-une-nouvelle-montre', '', '', '2016-05-17 00:08:19', '2016-05-16 22:08:19', '', 0, 'http://localhost:8888/onceuponawatch/?p=13', 0, 'post', '', 0),
(14, 1, '2016-05-17 00:08:13', '2016-05-16 22:08:13', '', 'visuel2', '', 'inherit', 'open', 'closed', '', 'visuel2', '', '', '2016-05-17 00:08:13', '2016-05-16 22:08:13', '', 13, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/visuel2.jpg', 0, 'attachment', 'image/jpeg', 0),
(15, 1, '2016-05-17 00:08:19', '2016-05-16 22:08:19', 'Le <strong>Lorem Ipsum</strong> est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre cinq siècles, mais s\'est aussi adapté à la bureautique informatique, sans que son contenu n\'en soit modifié. Il a été popularisé dans les années 1960 grâce à la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus récemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.', 'Comment avoir une nouvelle montre ?', '', 'inherit', 'closed', 'closed', '', '13-revision-v1', '', '', '2016-05-17 00:08:19', '2016-05-16 22:08:19', '', 13, 'http://localhost:8888/onceuponawatch/2016/05/17/13-revision-v1/', 0, 'revision', '', 0),
(16, 1, '2016-05-17 00:09:24', '2016-05-16 22:09:24', 'Le <strong>Lorem Ipsum</strong> est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre cinq siècles, mais s\'est aussi adapté à la bureautique informatique, sans que son contenu n\'en soit modifié. Il a été popularisé dans les années 1960 grâce à la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus récemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.', 'Je suis une montre moi aussi', '', 'publish', 'open', 'open', '', 'je-suis-une-montre-moi-aussi', '', '', '2016-05-17 00:09:24', '2016-05-16 22:09:24', '', 0, 'http://localhost:8888/onceuponawatch/?p=16', 0, 'post', '', 0),
(17, 1, '2016-05-17 00:09:17', '2016-05-16 22:09:17', '', 'testwatch', '', 'inherit', 'open', 'closed', '', 'testwatch', '', '', '2016-05-17 00:09:17', '2016-05-16 22:09:17', '', 16, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/testwatch.jpg', 0, 'attachment', 'image/jpeg', 0),
(18, 1, '2016-05-17 00:09:24', '2016-05-16 22:09:24', 'Le <strong>Lorem Ipsum</strong> est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre cinq siècles, mais s\'est aussi adapté à la bureautique informatique, sans que son contenu n\'en soit modifié. Il a été popularisé dans les années 1960 grâce à la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus récemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.', 'Je suis une montre moi aussi', '', 'inherit', 'closed', 'closed', '', '16-revision-v1', '', '', '2016-05-17 00:09:24', '2016-05-16 22:09:24', '', 16, 'http://localhost:8888/onceuponawatch/2016/05/17/16-revision-v1/', 0, 'revision', '', 0),
(19, 1, '2016-05-17 00:09:31', '2016-05-16 22:09:31', 'Bienvenue dans WordPress. Ceci est votre premier article. Modifiez-le ou supprimez-le, puis lancez-vous&nbsp;!', 'Bonjour tout le monde&nbsp;!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2016-05-17 00:09:31', '2016-05-16 22:09:31', '', 1, 'http://localhost:8888/onceuponawatch/2016/05/17/1-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2016-05-17 00:10:01', '2016-05-16 22:10:01', 'Le <strong>Lorem Ipsum</strong> est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre cinq siècles, mais s\'est aussi adapté à la bureautique informatique, sans que son contenu n\'en soit modifié. Il a été popularisé dans les années 1960 grâce à la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus récemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.', 'Et quoi d\'autre', '', 'publish', 'open', 'open', '', 'et-quoi-dautre', '', '', '2016-05-17 00:10:01', '2016-05-16 22:10:01', '', 0, 'http://localhost:8888/onceuponawatch/?p=20', 0, 'post', '', 1),
(21, 1, '2016-05-17 00:09:53', '2016-05-16 22:09:53', '', 'watch-in', '', 'inherit', 'open', 'closed', '', 'watch-in', '', '', '2016-05-17 00:09:53', '2016-05-16 22:09:53', '', 20, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/watch-in.jpg', 0, 'attachment', 'image/jpeg', 0),
(22, 1, '2016-05-17 00:10:01', '2016-05-16 22:10:01', 'Le <strong>Lorem Ipsum</strong> est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre cinq siècles, mais s\'est aussi adapté à la bureautique informatique, sans que son contenu n\'en soit modifié. Il a été popularisé dans les années 1960 grâce à la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus récemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.', 'Et quoi d\'autre', '', 'inherit', 'closed', 'closed', '', '20-revision-v1', '', '', '2016-05-17 00:10:01', '2016-05-16 22:10:01', '', 20, 'http://localhost:8888/onceuponawatch/2016/05/17/20-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2016-05-17 00:27:44', '2016-05-16 22:27:44', 'J\'suis un produit', 'Hello product', '', 'publish', 'open', 'closed', '', 'hello-product', '', '', '2016-05-19 17:08:10', '2016-05-19 15:08:10', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=product&#038;p=23', 0, 'product', '', 0),
(24, 1, '2016-05-17 01:10:48', '2016-05-16 23:10:48', 'Le <strong>Lorem Ipsum</strong> est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre cinq siècles, mais s\'est aussi adapté à la bureautique informatique, sans que son contenu n\'en soit modifié. Il a été popularisé dans les années 1960 grâce à la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus récemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.', 'Je suis une annonce', 'La nouvelle collection est arrivée, à cette occasion nous vous offrons 50% sur l\'achat d\'une deuxième montre', 'publish', 'open', 'closed', '', 'je-suis-une-annonce', '', '', '2016-05-17 01:11:35', '2016-05-16 23:11:35', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=annonces&#038;p=24', 0, 'annonces', '', 0),
(25, 1, '2016-05-17 01:10:42', '2016-05-16 23:10:42', '', 'watch-in', '', 'inherit', 'open', 'closed', '', 'watch-in-2', '', '', '2016-05-17 01:10:42', '2016-05-16 23:10:42', '', 24, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/watch-in-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(26, 1, '2016-05-17 01:10:48', '2016-05-16 23:10:48', 'La nouvelle collection est arrivée, à cette occasion nous vous offrons 50% sur l\'achat d\'une deuxième montre', 'Je suis une annonce', '', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2016-05-17 01:10:48', '2016-05-16 23:10:48', '', 24, 'http://localhost:8888/onceuponawatch/2016/05/17/24-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2016-05-17 01:11:35', '2016-05-16 23:11:35', 'Le <strong>Lorem Ipsum</strong> est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre cinq siècles, mais s\'est aussi adapté à la bureautique informatique, sans que son contenu n\'en soit modifié. Il a été popularisé dans les années 1960 grâce à la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus récemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.', 'Je suis une annonce', 'La nouvelle collection est arrivée, à cette occasion nous vous offrons 50% sur l\'achat d\'une deuxième montre', 'inherit', 'closed', 'closed', '', '24-revision-v1', '', '', '2016-05-17 01:11:35', '2016-05-16 23:11:35', '', 24, 'http://localhost:8888/onceuponawatch/2016/05/17/24-revision-v1/', 0, 'revision', '', 0),
(29, 1, '2016-05-17 01:12:07', '2016-05-16 23:12:07', 'Le <strong>Lorem Ipsum</strong> est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre cinq siècles, mais s\'est aussi adapté à la bureautique informatique, sans que son contenu n\'en soit modifié. Il a été popularisé dans les années 1960 grâce à la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus récemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.', 'Une autre annonce', 'Une autre annonce 50%', 'publish', 'open', 'closed', '', 'une-autre-annonce', '', '', '2016-05-17 01:12:07', '2016-05-16 23:12:07', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=annonces&#038;p=29', 0, 'annonces', '', 0),
(30, 1, '2016-05-17 01:12:03', '2016-05-16 23:12:03', '', 'header', '', 'inherit', 'open', 'closed', '', 'header', '', '', '2016-05-17 01:12:03', '2016-05-16 23:12:03', '', 29, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/header.jpg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2016-05-17 01:12:07', '2016-05-16 23:12:07', 'Le <strong>Lorem Ipsum</strong> est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre cinq siècles, mais s\'est aussi adapté à la bureautique informatique, sans que son contenu n\'en soit modifié. Il a été popularisé dans les années 1960 grâce à la vente de feuilles Letraset contenant des passages du Lorem Ipsum, et, plus récemment, par son inclusion dans des applications de mise en page de texte, comme Aldus PageMaker.', 'Une autre annonce', 'Une autre annonce 50%', 'inherit', 'closed', 'closed', '', '29-revision-v1', '', '', '2016-05-17 01:12:07', '2016-05-16 23:12:07', '', 29, 'http://localhost:8888/onceuponawatch/2016/05/17/29-revision-v1/', 0, 'revision', '', 0),
(32, 1, '2016-05-17 02:10:18', '2016-05-17 00:10:18', 'This example implies that there is only one template file being used for both categories and archives, e.g. simply <code>archive.php</code>.\r\nBut also that the template shows even other things, so this could simply be <code>index.php</code>.', 'La nouvelle collection est arrivée', 'Pour ca -50%', 'publish', 'open', 'closed', '', 'la-nouvelle-collection-est-arrivee', '', '', '2016-05-17 02:10:18', '2016-05-17 00:10:18', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=annonces&#038;p=32', 0, 'annonces', '', 0),
(33, 1, '2016-05-17 02:10:12', '2016-05-17 00:10:12', '', 'hands', '', 'inherit', 'open', 'closed', '', 'hands', '', '', '2016-05-17 02:10:12', '2016-05-17 00:10:12', '', 32, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/hands.jpg', 0, 'attachment', 'image/jpeg', 0),
(34, 1, '2016-05-17 02:10:18', '2016-05-17 00:10:18', 'This example implies that there is only one template file being used for both categories and archives, e.g. simply <code>archive.php</code>.\r\nBut also that the template shows even other things, so this could simply be <code>index.php</code>.', 'La nouvelle collection est arrivée', 'Pour ca -50%', 'inherit', 'closed', 'closed', '', '32-revision-v1', '', '', '2016-05-17 02:10:18', '2016-05-17 00:10:18', '', 32, 'http://localhost:8888/onceuponawatch/32-revision-v1/', 0, 'revision', '', 0),
(37, 1, '2016-05-17 02:48:06', '2016-05-17 00:48:06', '', 'Accueil', '', 'publish', 'closed', 'closed', '', 'accueil', '', '', '2016-05-25 13:45:03', '2016-05-25 11:45:03', '', 0, 'http://localhost:8888/onceuponawatch/?p=37', 1, 'nav_menu_item', '', 0),
(38, 1, '2016-05-17 03:06:10', '2016-05-17 01:06:10', 'C\'est une rolex !!!!', 'Une rolex', '', 'publish', 'open', 'closed', '', 'une-rolex', '', '', '2016-05-18 14:58:13', '2016-05-18 12:58:13', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=product&#038;p=38', 0, 'product', '', 2),
(40, 1, '2016-05-18 14:20:18', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-05-18 14:20:18', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/onceuponawatch/?p=40', 0, 'post', '', 0),
(51, 1, '2016-05-18 14:41:58', '2016-05-18 12:41:58', '', 'montre1', '', 'inherit', 'open', 'closed', '', 'montre1', '', '', '2016-05-18 14:41:58', '2016-05-18 12:41:58', '', 38, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/montre1.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2016-05-18 14:42:00', '2016-05-18 12:42:00', '', 'montre2', '', 'inherit', 'open', 'closed', '', 'montre2', '', '', '2016-05-18 14:42:00', '2016-05-18 12:42:00', '', 38, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/montre2.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2016-05-18 14:42:01', '2016-05-18 12:42:01', '', 'montre3', '', 'inherit', 'open', 'closed', '', 'montre3', '', '', '2016-05-18 14:42:01', '2016-05-18 12:42:01', '', 38, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/montre3.jpg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2016-05-18 14:42:03', '2016-05-18 12:42:03', '', 'montre4', '', 'inherit', 'open', 'closed', '', 'montre4', '', '', '2016-05-18 14:42:03', '2016-05-18 12:42:03', '', 38, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/montre4.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2016-05-18 18:00:22', '2016-05-18 16:00:22', 'C\'est un bracelet', 'Bracelet apple watch', '', 'publish', 'open', 'closed', '', 'bracelet-apple-watch', '', '', '2016-05-18 18:00:22', '2016-05-18 16:00:22', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=product&#038;p=55', 0, 'product', '', 1),
(56, 1, '2016-05-18 18:06:34', '2016-05-18 16:06:34', 'Je suis une festina', 'Festina', '', 'publish', 'open', 'closed', '', 'festina', '', '', '2016-05-24 11:32:42', '2016-05-24 09:32:42', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=product&#038;p=56', 0, 'product', '', 0),
(57, 1, '2016-05-19 14:27:52', '2016-05-19 12:27:52', '', 'Mode-Bracelets-montre-femme-chaude-montres-de-haute-qualité-femmes-en-cuir-véritable-Vintage-montre-bracelet', '', 'inherit', 'open', 'closed', '', 'mode-bracelets-montre-femme-chaude-montres-de-haute-qualite-femmes-en-cuir-veritable-vintage-montre-bracelet', '', '', '2016-05-19 14:27:52', '2016-05-19 12:27:52', '', 0, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/Mode-Bracelets-montre-femme-chaude-montres-de-haute-qualité-femmes-en-cuir-véritable-Vintage-montre-bracelet.jpg', 0, 'attachment', 'image/jpeg', 0),
(58, 1, '2016-05-19 17:00:00', '2016-05-19 15:00:00', 'Le <strong>Lorem Ipsum</strong> est simplement du faux texte employé dans la composition et la mise en page avant impression. Le Lorem Ipsum est le faux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre ci', 'J\'suis une rolex', '', 'publish', 'open', 'closed', '', 'jsuis-une-rolex', '', '', '2016-05-19 17:27:07', '2016-05-19 15:27:07', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=product&#038;p=58', 0, 'product', '', 2),
(59, 1, '2016-05-19 16:59:48', '2016-05-19 14:59:48', '', 'montre4', '', 'inherit', 'open', 'closed', '', 'montre4-2', '', '', '2016-05-19 16:59:48', '2016-05-19 14:59:48', '', 58, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/montre4-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2016-05-19 17:06:11', '2016-05-19 15:06:11', '', 'montre3', '', 'inherit', 'open', 'closed', '', 'montre3-2', '', '', '2016-05-19 17:06:11', '2016-05-19 15:06:11', '', 23, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/montre3-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2016-05-19 17:38:10', '2016-05-19 15:38:10', '', 'Montres', '', 'publish', 'closed', 'closed', '', 'montres', '', '', '2016-05-25 13:45:03', '2016-05-25 11:45:03', '', 0, 'http://localhost:8888/onceuponawatch/?p=61', 2, 'nav_menu_item', '', 0),
(62, 1, '2016-05-19 17:38:10', '2016-05-19 15:38:10', '', 'Bracelets', '', 'publish', 'closed', 'closed', '', 'bracelets', '', '', '2016-05-25 13:45:03', '2016-05-25 11:45:03', '', 0, 'http://localhost:8888/onceuponawatch/?p=62', 3, 'nav_menu_item', '', 0),
(63, 1, '2016-05-19 18:08:35', '2016-05-19 16:08:35', '', 'Order &ndash; mai 19, 2016 @ 06:08  ', '', 'wc-processing', 'open', 'closed', 'order_573de427b87ff', 'commande-may-19-2016-0404-pm', '', '', '2016-05-19 18:08:35', '2016-05-19 16:08:35', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=shop_order&#038;p=63', 0, 'shop_order', '', 1),
(64, 1, '2016-05-19 18:06:14', '2016-05-19 16:06:14', 'Aux texte standard de l\'imprimerie depuis les années 1500, quand un peintre anonyme assembla ensemble des morceaux de texte pour réaliser un livre spécimen de polices de texte. Il n\'a pas fait que survivre cinq siècles, mais s\'est aussi adapté à la bureautique informatique, sans que son contenu n\'en soit modifié. Il a été popularisé dans les années 1960 grâce à la vente de feuilles Letraset contenant des passages du Lore', 'Produit téléchargeable', '', 'publish', 'open', 'closed', '', 'produit-telechargeable', '', '', '2016-05-19 18:06:14', '2016-05-19 16:06:14', '', 0, 'http://localhost:8888/onceuponawatch/?post_type=product&#038;p=64', 0, 'product', '', 0),
(65, 1, '2016-05-19 18:05:51', '2016-05-19 16:05:51', '', 'montre1', '', 'inherit', 'open', 'closed', '', 'montre1-2', '', '', '2016-05-19 18:05:51', '2016-05-19 16:05:51', '', 64, 'http://localhost:8888/onceuponawatch/wp-content/uploads/2016/05/montre1-1.jpg', 0, 'attachment', 'image/jpeg', 0),
(66, 1, '2016-05-19 18:30:24', '2016-05-19 16:30:24', '[contact-form-7 id="12" title="Contact form 1"]', 'Contact', '', 'publish', 'closed', 'closed', '', 'contact', '', '', '2016-05-25 14:53:22', '2016-05-25 12:53:22', '', 0, 'http://localhost:8888/onceuponawatch/?page_id=66', 0, 'page', '', 0),
(67, 1, '2016-05-19 18:30:24', '2016-05-19 16:30:24', '', 'Contact', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2016-05-19 18:30:24', '2016-05-19 16:30:24', '', 66, 'http://localhost:8888/onceuponawatch/66-revision-v1/', 0, 'revision', '', 0),
(68, 1, '2016-05-19 18:30:37', '2016-05-19 16:30:37', ' ', '', '', 'publish', 'closed', 'closed', '', '68', '', '', '2016-05-25 13:45:03', '2016-05-25 11:45:03', '', 0, 'http://localhost:8888/onceuponawatch/?p=68', 5, 'nav_menu_item', '', 0),
(69, 1, '2016-05-22 23:37:51', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'closed', 'closed', '', '', '', '', '2016-05-22 23:37:51', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/onceuponawatch/?page_id=69', 0, 'page', '', 0),
(70, 1, '2016-05-22 23:41:04', '2016-05-22 21:41:04', '[wpmem_form register]', 'Inscription', '', 'publish', 'closed', 'closed', '', 'inscription', '', '', '2016-05-22 23:48:49', '2016-05-22 21:48:49', '', 0, 'http://localhost:8888/onceuponawatch/?page_id=70', 0, 'page', '', 0),
(71, 1, '2016-05-22 23:41:04', '2016-05-22 21:41:04', '', 'Inscription', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2016-05-22 23:41:04', '2016-05-22 21:41:04', '', 70, 'http://localhost:8888/onceuponawatch/70-revision-v1/', 0, 'revision', '', 0),
(72, 1, '2016-05-22 23:48:49', '2016-05-22 21:48:49', '[wpmem_form register]', 'Inscription', '', 'inherit', 'closed', 'closed', '', '70-revision-v1', '', '', '2016-05-22 23:48:49', '2016-05-22 21:48:49', '', 70, 'http://localhost:8888/onceuponawatch/70-revision-v1/', 0, 'revision', '', 0),
(73, 1, '2016-05-23 00:06:03', '2016-05-22 22:06:03', '[contact-form-7 id="12" title="Contact form 1"]', 'Contact', '', 'inherit', 'closed', 'closed', '', '66-revision-v1', '', '', '2016-05-23 00:06:03', '2016-05-22 22:06:03', '', 66, 'http://localhost:8888/onceuponawatch/66-revision-v1/', 0, 'revision', '', 0),
(74, 1, '2016-05-23 00:18:20', '0000-00-00 00:00:00', '', 'Nouveautés', '', 'draft', 'closed', 'closed', '', '', '', '', '2016-05-23 00:18:20', '2016-05-22 22:18:20', '', 0, 'http://localhost:8888/onceuponawatch/?page_id=74', 0, 'page', '', 0),
(75, 1, '2016-05-23 00:19:59', '2016-05-22 22:19:59', '', 'Nouveautés', '', 'publish', 'closed', 'closed', '', 'nouveautes', '', '', '2016-05-23 00:19:59', '2016-05-22 22:19:59', '', 0, 'http://localhost:8888/onceuponawatch/?page_id=75', 0, 'page', '', 0),
(76, 1, '2016-05-23 00:19:59', '2016-05-22 22:19:59', '', 'Nouveautés', '', 'inherit', 'closed', 'closed', '', '75-revision-v1', '', '', '2016-05-23 00:19:59', '2016-05-22 22:19:59', '', 75, 'http://localhost:8888/onceuponawatch/75-revision-v1/', 0, 'revision', '', 0),
(77, 1, '2016-05-23 00:20:24', '2016-05-22 22:20:24', ' ', '', '', 'publish', 'closed', 'closed', '', '77', '', '', '2016-05-25 13:45:03', '2016-05-25 11:45:03', '', 0, 'http://localhost:8888/onceuponawatch/?p=77', 4, 'nav_menu_item', '', 0) ;

#
# End of data contents of table `wp_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_relationships`
#

DROP TABLE IF EXISTS `wp_term_relationships`;


#
# Table structure of table `wp_term_relationships`
#

CREATE TABLE `wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_relationships`
#
INSERT INTO `wp_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(8, 2, 0),
(9, 2, 0),
(9, 12, 0),
(13, 6, 0),
(16, 6, 0),
(20, 6, 0),
(23, 2, 0),
(23, 12, 0),
(23, 18, 0),
(37, 7, 0),
(38, 2, 0),
(38, 11, 0),
(38, 19, 0),
(55, 2, 0),
(55, 9, 0),
(56, 2, 0),
(56, 12, 0),
(58, 2, 0),
(58, 11, 0),
(58, 19, 0),
(58, 20, 0),
(61, 7, 0),
(62, 7, 0),
(64, 2, 0),
(64, 12, 0),
(68, 7, 0),
(77, 7, 0) ;

#
# End of data contents of table `wp_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_term_taxonomy`;


#
# Table structure of table `wp_term_taxonomy`
#

CREATE TABLE `wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_term_taxonomy`
#
INSERT INTO `wp_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 0),
(2, 2, 'product_type', '', 0, 7),
(3, 3, 'product_type', '', 0, 0),
(4, 4, 'product_type', '', 0, 0),
(5, 5, 'product_type', '', 0, 0),
(6, 6, 'category', '', 0, 3),
(7, 7, 'nav_menu', '', 0, 5),
(8, 8, 'nav_menu', '', 0, 0),
(9, 9, 'product_cat', '', 0, 1),
(10, 10, 'product_cat', '', 0, 0),
(11, 11, 'product_cat', '', 10, 2),
(12, 12, 'product_cat', '', 10, 4),
(18, 18, 'pa_couleur', '', 0, 1),
(19, 19, 'pa_couleur', '', 0, 2),
(20, 20, 'pa_couleur', '', 0, 1) ;

#
# End of data contents of table `wp_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_termmeta`
#

DROP TABLE IF EXISTS `wp_termmeta`;


#
# Table structure of table `wp_termmeta`
#

CREATE TABLE `wp_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_termmeta`
#

#
# End of data contents of table `wp_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_terms`
#

DROP TABLE IF EXISTS `wp_terms`;


#
# Table structure of table `wp_terms`
#

CREATE TABLE `wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_terms`
#
INSERT INTO `wp_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Non classé', 'non-classe', 0),
(2, 'simple', 'simple', 0),
(3, 'grouped', 'grouped', 0),
(4, 'variable', 'variable', 0),
(5, 'external', 'external', 0),
(6, 'Montres', 'montres', 0),
(7, 'headmenu', 'headmenu', 0),
(8, 'custommenu', 'custommenu', 0),
(9, 'Bracelets', 'bracelets', 0),
(10, 'Montres', 'montres', 0),
(11, 'Rolex', 'rolex', 0),
(12, 'Festina', 'festina', 0),
(18, 'Bleu', 'bleu', 0),
(19, 'Noir', 'noir', 0),
(20, 'Rouge', 'rouge', 0) ;

#
# End of data contents of table `wp_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_usermeta`
#

DROP TABLE IF EXISTS `wp_usermeta`;


#
# Table structure of table `wp_usermeta`
#

CREATE TABLE `wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_usermeta`
#
INSERT INTO `wp_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'Alex'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'false'),
(10, 1, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '1'),
(15, 1, 'wp_dashboard_quick_press_last_post_id', '40'),
(16, 1, 'manageedit-shop_ordercolumnshidden', 'a:1:{i:0;s:15:"billing_address";}'),
(17, 1, 'wp_user-settings', 'libraryContent=browse&editor=html'),
(18, 1, 'wp_user-settings-time', '1463693701'),
(20, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(21, 1, 'metaboxhidden_nav-menus', 'a:8:{i:0;s:30:"woocommerce_endpoints_nav_link";i:1;s:13:"hptal-metabox";i:2;s:22:"add-post-type-annonces";i:3;s:21:"add-post-type-product";i:4;s:12:"add-post_tag";i:5;s:15:"add-post_format";i:6;s:15:"add-product_cat";i:7;s:15:"add-product_tag";}'),
(22, 1, 'nav_menu_recently_edited', '7'),
(23, 1, 'closedpostboxes_product', 'a:0:{}'),
(24, 1, 'metaboxhidden_product', 'a:1:{i:0;s:7:"slugdiv";}'),
(26, 1, 'billing_first_name', 'Alexandre'),
(27, 1, 'billing_last_name', 'Kong'),
(28, 1, 'billing_company', 'Webdesigner'),
(29, 1, 'billing_email', 'alexandre.kong@gmail.com'),
(30, 1, 'billing_phone', '0666534526'),
(31, 1, 'billing_country', 'FR'),
(32, 1, 'billing_address_1', '14 rue de la Hautemontée'),
(33, 1, 'billing_address_2', ''),
(34, 1, 'billing_city', 'Strasbourg'),
(35, 1, 'billing_state', ''),
(36, 1, 'billing_postcode', '67000'),
(37, 1, '_woocommerce_persistent_cart', 'a:1:{s:4:"cart";a:3:{s:32:"66f041e16a60928b05a7e228a89c3799";a:9:{s:10:"product_id";i:58;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:3;s:10:"line_total";d:37161;s:8:"line_tax";i:0;s:13:"line_subtotal";i:37161;s:17:"line_subtotal_tax";i:0;s:13:"line_tax_data";a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}}s:32:"a5771bce93e200c36f7cd9dfd0e5deaa";a:9:{s:10:"product_id";i:38;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:7;s:10:"line_total";d:700;s:8:"line_tax";i:0;s:13:"line_subtotal";i:700;s:17:"line_subtotal_tax";i:0;s:13:"line_tax_data";a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}}s:32:"9f61408e3afb633e50cdf1b20de6f466";a:9:{s:10:"product_id";i:56;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:10:"line_total";d:123;s:8:"line_tax";i:0;s:13:"line_subtotal";i:123;s:17:"line_subtotal_tax";i:0;s:13:"line_tax_data";a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}}}}'),
(38, 1, 'session_tokens', 'a:4:{s:64:"2ca447544afe2b80741a44cf21d373b9bc121bb22fda57a10bd54c7541e61850";a:4:{s:10:"expiration";i:1464272675;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36";s:5:"login";i:1464099875;}s:64:"3286b888784fd2b91a8578bac3f26d5a2125ec4c9e8205ce4d27e862b8c89dc5";a:4:{s:10:"expiration";i:1464353187;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36";s:5:"login";i:1464180387;}s:64:"b4eb5f54a992bcb808af87fd0e073a75c8c6e89befbd629066ac9057970db520";a:4:{s:10:"expiration";i:1464364575;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36";s:5:"login";i:1464191775;}s:64:"20b9dd02382f206decd5dc60eb51c8c4b2d048f897ce052c383a9183e1dc548c";a:4:{s:10:"expiration";i:1464366846;s:2:"ip";s:3:"::1";s:2:"ua";s:120:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36";s:5:"login";i:1464194046;}}'),
(39, 1, 'wpseo_seen_about_version', '3.2.5'),
(40, 1, 'wpseo_ignore_tour', '1') ;

#
# End of data contents of table `wp_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_users`
#

DROP TABLE IF EXISTS `wp_users`;


#
# Table structure of table `wp_users`
#

CREATE TABLE `wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_users`
#
INSERT INTO `wp_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'Alex', '$P$BMu3d7cHuAcS1JxcGYzQYgqXko0qQF/', 'alex', 'alexandre.kong@gmail.com', '', '2016-05-10 23:46:42', '', 0, 'Alex') ;

#
# End of data contents of table `wp_users`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_api_keys`
#

DROP TABLE IF EXISTS `wp_woocommerce_api_keys`;


#
# Table structure of table `wp_woocommerce_api_keys`
#

CREATE TABLE `wp_woocommerce_api_keys` (
  `key_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `description` longtext COLLATE utf8_unicode_ci,
  `permissions` varchar(10) COLLATE utf8_unicode_ci NOT NULL,
  `consumer_key` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `consumer_secret` char(43) COLLATE utf8_unicode_ci NOT NULL,
  `nonces` longtext COLLATE utf8_unicode_ci,
  `truncated_key` char(7) COLLATE utf8_unicode_ci NOT NULL,
  `last_access` datetime DEFAULT NULL,
  PRIMARY KEY (`key_id`),
  KEY `consumer_key` (`consumer_key`),
  KEY `consumer_secret` (`consumer_secret`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_api_keys`
#

#
# End of data contents of table `wp_woocommerce_api_keys`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_attribute_taxonomies`
#

DROP TABLE IF EXISTS `wp_woocommerce_attribute_taxonomies`;


#
# Table structure of table `wp_woocommerce_attribute_taxonomies`
#

CREATE TABLE `wp_woocommerce_attribute_taxonomies` (
  `attribute_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `attribute_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `attribute_label` longtext COLLATE utf8_unicode_ci,
  `attribute_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `attribute_orderby` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `attribute_public` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`attribute_id`),
  KEY `attribute_name` (`attribute_name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_attribute_taxonomies`
#
INSERT INTO `wp_woocommerce_attribute_taxonomies` ( `attribute_id`, `attribute_name`, `attribute_label`, `attribute_type`, `attribute_orderby`, `attribute_public`) VALUES
(3, 'couleur', 'Couleur', 'select', 'menu_order', 0) ;

#
# End of data contents of table `wp_woocommerce_attribute_taxonomies`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_downloadable_product_permissions`
#

DROP TABLE IF EXISTS `wp_woocommerce_downloadable_product_permissions`;


#
# Table structure of table `wp_woocommerce_downloadable_product_permissions`
#

CREATE TABLE `wp_woocommerce_downloadable_product_permissions` (
  `permission_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `download_id` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL DEFAULT '0',
  `order_key` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `user_email` varchar(200) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `downloads_remaining` varchar(9) COLLATE utf8_unicode_ci DEFAULT NULL,
  `access_granted` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `access_expires` datetime DEFAULT NULL,
  `download_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`permission_id`),
  KEY `download_order_key_product` (`product_id`,`order_id`,`order_key`(191),`download_id`),
  KEY `download_order_product` (`download_id`,`order_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_downloadable_product_permissions`
#

#
# End of data contents of table `wp_woocommerce_downloadable_product_permissions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_itemmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_itemmeta`;


#
# Table structure of table `wp_woocommerce_order_itemmeta`
#

CREATE TABLE `wp_woocommerce_order_itemmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `order_item_id` (`order_item_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=118 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_order_itemmeta`
#
INSERT INTO `wp_woocommerce_order_itemmeta` ( `meta_id`, `order_item_id`, `meta_key`, `meta_value`) VALUES
(109, 13, '_qty', '1'),
(110, 13, '_tax_class', ''),
(111, 13, '_product_id', '64'),
(112, 13, '_variation_id', '0'),
(113, 13, '_line_subtotal', '0'),
(114, 13, '_line_total', '0'),
(115, 13, '_line_subtotal_tax', '0'),
(116, 13, '_line_tax', '0'),
(117, 13, '_line_tax_data', 'a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}') ;

#
# End of data contents of table `wp_woocommerce_order_itemmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_order_items`
#

DROP TABLE IF EXISTS `wp_woocommerce_order_items`;


#
# Table structure of table `wp_woocommerce_order_items`
#

CREATE TABLE `wp_woocommerce_order_items` (
  `order_item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `order_item_name` longtext COLLATE utf8_unicode_ci NOT NULL,
  `order_item_type` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `order_id` bigint(20) NOT NULL,
  PRIMARY KEY (`order_item_id`),
  KEY `order_id` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_order_items`
#
INSERT INTO `wp_woocommerce_order_items` ( `order_item_id`, `order_item_name`, `order_item_type`, `order_id`) VALUES
(13, 'Produit téléchargeable', 'line_item', 63) ;

#
# End of data contents of table `wp_woocommerce_order_items`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_sessions`
#

DROP TABLE IF EXISTS `wp_woocommerce_sessions`;


#
# Table structure of table `wp_woocommerce_sessions`
#

CREATE TABLE `wp_woocommerce_sessions` (
  `session_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `session_key` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `session_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `session_expiry` bigint(20) NOT NULL,
  PRIMARY KEY (`session_key`),
  UNIQUE KEY `session_id` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_sessions`
#
INSERT INTO `wp_woocommerce_sessions` ( `session_id`, `session_key`, `session_value`, `session_expiry`) VALUES
(67, '1', 'a:18:{s:4:"cart";s:907:"a:3:{s:32:"66f041e16a60928b05a7e228a89c3799";a:9:{s:10:"product_id";i:58;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:3;s:10:"line_total";d:37161;s:8:"line_tax";i:0;s:13:"line_subtotal";i:37161;s:17:"line_subtotal_tax";i:0;s:13:"line_tax_data";a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}}s:32:"a5771bce93e200c36f7cd9dfd0e5deaa";a:9:{s:10:"product_id";i:38;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:7;s:10:"line_total";d:700;s:8:"line_tax";i:0;s:13:"line_subtotal";i:700;s:17:"line_subtotal_tax";i:0;s:13:"line_tax_data";a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}}s:32:"9f61408e3afb633e50cdf1b20de6f466";a:9:{s:10:"product_id";i:56;s:12:"variation_id";i:0;s:9:"variation";a:0:{}s:8:"quantity";i:1;s:10:"line_total";d:123;s:8:"line_tax";i:0;s:13:"line_subtotal";i:123;s:17:"line_subtotal_tax";i:0;s:13:"line_tax_data";a:2:{s:5:"total";a:0:{}s:8:"subtotal";a:0:{}}}}";s:15:"applied_coupons";s:6:"a:0:{}";s:23:"coupon_discount_amounts";s:6:"a:0:{}";s:27:"coupon_discount_tax_amounts";s:6:"a:0:{}";s:21:"removed_cart_contents";s:6:"a:0:{}";s:19:"cart_contents_total";d:37984;s:5:"total";i:0;s:8:"subtotal";i:37984;s:15:"subtotal_ex_tax";i:37984;s:9:"tax_total";i:0;s:5:"taxes";s:6:"a:0:{}";s:14:"shipping_taxes";s:6:"a:0:{}";s:13:"discount_cart";i:0;s:17:"discount_cart_tax";i:0;s:14:"shipping_total";i:0;s:18:"shipping_tax_total";i:0;s:9:"fee_total";i:0;s:4:"fees";s:6:"a:0:{}";}', 1464364575) ;

#
# End of data contents of table `wp_woocommerce_sessions`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rate_locations`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rate_locations`;


#
# Table structure of table `wp_woocommerce_tax_rate_locations`
#

CREATE TABLE `wp_woocommerce_tax_rate_locations` (
  `location_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `location_code` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tax_rate_id` bigint(20) NOT NULL,
  `location_type` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`location_id`),
  KEY `tax_rate_id` (`tax_rate_id`),
  KEY `location_type` (`location_type`),
  KEY `location_type_code` (`location_type`,`location_code`(90))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_tax_rate_locations`
#

#
# End of data contents of table `wp_woocommerce_tax_rate_locations`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_tax_rates`
#

DROP TABLE IF EXISTS `wp_woocommerce_tax_rates`;


#
# Table structure of table `wp_woocommerce_tax_rates`
#

CREATE TABLE `wp_woocommerce_tax_rates` (
  `tax_rate_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tax_rate_country` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_state` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_rate` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `tax_rate_priority` bigint(20) NOT NULL,
  `tax_rate_compound` int(1) NOT NULL DEFAULT '0',
  `tax_rate_shipping` int(1) NOT NULL DEFAULT '1',
  `tax_rate_order` bigint(20) NOT NULL,
  `tax_rate_class` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`tax_rate_id`),
  KEY `tax_rate_country` (`tax_rate_country`(191)),
  KEY `tax_rate_state` (`tax_rate_state`(191)),
  KEY `tax_rate_class` (`tax_rate_class`(191)),
  KEY `tax_rate_priority` (`tax_rate_priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_tax_rates`
#

#
# End of data contents of table `wp_woocommerce_tax_rates`
# --------------------------------------------------------



#
# Delete any existing table `wp_woocommerce_termmeta`
#

DROP TABLE IF EXISTS `wp_woocommerce_termmeta`;


#
# Table structure of table `wp_woocommerce_termmeta`
#

CREATE TABLE `wp_woocommerce_termmeta` (
  `meta_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `woocommerce_term_id` bigint(20) NOT NULL,
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `woocommerce_term_id` (`woocommerce_term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_woocommerce_termmeta`
#
INSERT INTO `wp_woocommerce_termmeta` ( `meta_id`, `woocommerce_term_id`, `meta_key`, `meta_value`) VALUES
(1, 9, 'order', '0'),
(2, 9, 'display_type', 'products'),
(3, 9, 'thumbnail_id', '57'),
(4, 10, 'order', '0'),
(5, 10, 'display_type', 'products'),
(6, 10, 'thumbnail_id', '14'),
(7, 11, 'order', '0'),
(8, 11, 'display_type', 'subcategories'),
(9, 11, 'thumbnail_id', '0'),
(10, 12, 'order', '0'),
(11, 12, 'display_type', 'subcategories'),
(12, 12, 'thumbnail_id', '0'),
(13, 11, 'product_count_product_cat', '2'),
(14, 10, 'product_count_product_cat', '6'),
(18, 12, 'product_count_product_cat', '4'),
(23, 18, 'order_pa_couleur', '0'),
(24, 19, 'order_pa_couleur', '0'),
(25, 20, 'order_pa_couleur', '0'),
(28, 9, 'product_count_product_cat', '1'),
(38, 18, 'product_ids', 'a:1:{i:0;s:2:"23";}'),
(41, 19, 'product_ids', 'a:2:{i:0;s:2:"38";i:1;s:2:"58";}'),
(42, 20, 'product_ids', 'a:1:{i:0;s:2:"58";}') ;

#
# End of data contents of table `wp_woocommerce_termmeta`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

